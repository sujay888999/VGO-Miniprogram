const QQMapWX = require('./libs/qqmap-wx-jssdk.js');

const DEFAULT_AVATAR = "/images/default-avatar.png"

App({

  globalData: {
    userInfo: null,
    role: "",
    phone: "",
    userPhone: "",
    openid: "",
    auth: null,
    qqmapsdk: new QQMapWX({
      key: '3I2BZ-CBRKQ-2NY5U-2UWEX-AS6I2-FQBZL'
    })
  },

  onLaunch() {
    wx.cloud.init({
      env: 'cloudbase-6g92d8af5bbb55dd',
    })

    const auth = this.loadAuthFromStorage()
    if (auth) {
      this.globalData.auth = auth
      this.globalData.role = auth.role
      this.globalData.phone = auth.phone
    }
  },

  loadAuthFromStorage() {
    try {
      const auth = wx.getStorageSync("auth")
      if (!auth || !auth.openid || !auth.isLogged) return null
      return this.normalizeAuth(auth)
    } catch (e) {
      return null
    }
  },

  normalizeAuth(auth) {
    if (!auth) return null
    return {
      ...auth,
      avatar: auth.avatar || DEFAULT_AVATAR
    }
  },

  // 保存登录状态
  saveAuth(auth) {
    if (!auth) return
    const normalized = this.normalizeAuth(auth)
    wx.setStorageSync("auth", normalized)
    wx.setStorageSync('openid', normalized.openid || '')
    wx.setStorageSync('phone', normalized.phone || '')
    this.globalData.auth = normalized
    this.globalData.phone = normalized.phone
    this.globalData.userPhone = normalized.phone || ""
    this.globalData.openid = normalized.openid || ""
  },

  // 校验登录状态（单一账号体系：登录一次即可，司机只需额外注册）
  ensureAuth(options = {}) {
    const auth = this.loadAuthFromStorage()

    if (!auth || !auth.openid) {
      this.promptLogin()
      return null
    }

    // 统一返回登录信息，不再进行角色判断
    this.globalData.auth = auth
    this.globalData.openid = auth.openid || ""
    this.globalData.phone = auth.phone || ""
    this.globalData.userPhone = auth.phone || ""

    return this.normalizeAuth(auth)
  },


  promptLogin() {
    wx.showToast({
      title: "请先登录",
      icon: "none"
    })
    setTimeout(() => {
      wx.navigateTo({
        url: "/pages/login/login"
      })
    }, 700)
  },

  redirectToRoleHome(role) {
    const target = role === "driver"
      ? "/pages/driver/index/index"
      : "/pages/passenger/index/index"
    wx.reLaunch({ url: target })
  },

  // 退出登录
  logout() {
    wx.removeStorageSync("auth")
    this.globalData.auth = null
    this.globalData.role = ""
    this.globalData.phone = ""

    wx.showToast({
      title: "已退出登录",
      icon: "none"
    })

    setTimeout(() => {
      wx.reLaunch({
        url: "/pages/index/index"
      })
    }, 800)
  },

  async uploadAvatar(tempFilePath) {
    if (!tempFilePath) throw new Error("NO_FILE")
    const auth = this.globalData.auth || this.loadAuthFromStorage()
    if (!auth || !auth.openid) {
      throw new Error("NOT_LOGGED_IN")
    }

    const extensionMatch = /\.[^.]+$/.exec(tempFilePath)
    const ext = extensionMatch ? extensionMatch[0] : ".jpg"
    const cloudPath = `avatars/${auth.openid}_${Date.now()}${ext}`

    const uploadRes = await wx.cloud.uploadFile({
      cloudPath,
      filePath: tempFilePath
    })

    const db = wx.cloud.database()
    const updateRes = await db.collection("users").where({
      _openid: auth.openid
    }).update({
      data: {
        avatar: uploadRes.fileID,
        updateTime: db.serverDate()
      }
    })

    if (!updateRes.stats || updateRes.stats.updated === 0) {
      await db.collection("users").add({
        data: {
          _openid: auth.openid,
          phone: auth.phone || "",
          role: auth.role || "",
          avatar: uploadRes.fileID,
          createTime: db.serverDate(),
          updateTime: db.serverDate()
        }
      })
    }

    const updatedAuth = { ...auth, avatar: uploadRes.fileID }
    this.saveAuth(updatedAuth)
    return uploadRes.fileID
  }

})
