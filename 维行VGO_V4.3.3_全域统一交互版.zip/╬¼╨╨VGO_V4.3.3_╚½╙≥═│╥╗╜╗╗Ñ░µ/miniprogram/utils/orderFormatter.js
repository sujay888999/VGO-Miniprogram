// miniprogram/utils/orderFormatter.js

function formatAddress(address) {
  if (!address) return '未知地点'

  // 如果是字符串，直接返回
  if (typeof address === 'string') return address

  // 优先识别 address.name → 再看 address.address → fallback "未知地点"
  // 支持 fromAddress.name / toAddress.name 结构
  if (address.name) return address.name
  if (address.address) return address.address

  // 如果字段为对象且缺 name/address 字段，显示"未知地点"
  return '未知地点'
}

function formatDate(dt) {
  if (!dt) return ''

  try {
    // 兼容 Date 对象 / 时间戳 / ISO 字符串
    return new Date(dt).toLocaleString('zh-CN')
  } catch (e) {
    return String(dt)
  }
}

/**
 * distance:
 * - 可能是米（number）
 * - 可能是公里（number）
 */
function formatDistance(distance) {
  if (distance == null || isNaN(distance)) return '未知距离'

  const d = Number(distance)

  // 大于 1000 认为是米，转公里
  if (d > 1000) {
    return `约 ${(d / 1000).toFixed(1)} 公里`
  }

  // 小于 1000 就直接当公里（已经是 km）
  if (d > 0 && d <= 1000) {
    return `约 ${d.toFixed(1)} 公里`
  }

  return '未知距离'
}

/**
 * duration:
 * - 可能是秒
 * - 可能是分钟
 */
function formatDuration(duration) {
  if (duration == null || isNaN(duration)) return '未知时长'

  const t = Number(duration)

  // 大于 120 认为是秒
  if (t > 120) {
    const minutes = Math.round(t / 60)
    return `约 ${minutes} 分钟`
  }

  if (t > 0) {
    return `约 ${t.toFixed(0)} 分钟`
  }

  return '未知时长'
}

/**
 * 状态映射函数：将旧状态转换为新状态（方案 A）
 */
function normalizeStatus(oldStatus) {
  switch (oldStatus) {
    case 'waiting':
    case '待匹配':
    case 'pending':
      return 'waitingDriverBid';
    case 'bidding':
    case 'waitingBid':
    case 'bidPending':
      return 'bidding';
    case 'matched':
    case 'accepted':
    case '司机已接单':
      return 'accepted';
    case 'going':
    case '进行中':
    case 'trip':
    case 'tripStarted':
      return 'tripStarted';
    case 'finished':
    case '已完成':
    case 'completed':
      return 'completed';
    case 'canceled':
    case 'cancelled':
    case '已取消':
      return 'cancelled';
    case 'picking':
      return 'picking';
    case 'onboard':
      return 'onboard';
    case 'passengerSelect':
      return 'passengerSelect';
    default:
      return oldStatus || 'waitingDriverBid';
  }
}

/**
 * 格式化订单状态为中文显示（方案 A）
 */
function formatStatus(status) {
  // 先标准化状态
  const normalizedStatus = normalizeStatus(status);
  
  const statusMap = {
    waitingDriverBid: '等待司机抢单',
    bidding: '司机报价中',
    passengerSelect: '等待乘客选择司机',
    accepted: '司机已接单，待接乘客',
    picking: '司机前往上车点',
    onboard: '乘客已上车',
    tripStarted: '行程进行中',
    completed: '已完成',
    cancelled: '已取消',
  };
  return statusMap[normalizedStatus] || normalizedStatus || '未知状态';
}

module.exports = {
  formatAddress,
  formatDate,
  formatDistance,
  formatDuration,
  formatStatus,
  normalizeStatus,
}
