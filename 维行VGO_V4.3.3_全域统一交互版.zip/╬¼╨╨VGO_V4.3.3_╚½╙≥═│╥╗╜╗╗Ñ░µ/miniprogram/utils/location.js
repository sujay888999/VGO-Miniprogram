export function getLocation() {
  return new Promise((resolve, reject) => {
    wx.getLocation({
      type: 'gcj02',
      success: res => resolve({ lat: res.latitude, lng: res.longitude }),
      fail: reject
    })
  })
}

