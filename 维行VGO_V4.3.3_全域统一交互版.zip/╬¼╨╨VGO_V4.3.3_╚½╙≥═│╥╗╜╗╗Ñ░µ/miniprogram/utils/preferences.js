
const PREFERENCES_KEY = 'vgo_user_preferences'

const defaultPreferences = {
  music: 'quiet',           // quiet / light / dynamic
  chat: false,              // 是否喜欢聊天
  fragrance: 'none',        // none / light / woody / floral
  window: true,             // 喜欢开窗
  temperature: [22, 26],    // 温度范围
  pet: false,               // 是否允许宠物
  luggage: true,            // 需要协助搬运行李
  seat: 'rear-left',        // rear-left / rear-right / front
  noise: 'low',             // 环境噪音容忍度
  motion_sensitivity: 'mid',// low / mid / high
  language: 'zh',           // zh / en
  comfortLevel: 'standard'  // standard / premium / lux
}

export function getPreferences() {
  try {
    const stored = wx.getStorageSync(PREFERENCES_KEY)
    if (!stored) return { ...defaultPreferences }
    return { ...defaultPreferences, ...stored }
  } catch (e) {
    return { ...defaultPreferences }
  }
}

export function savePreferences(prefs) {
  const merged = { ...defaultPreferences, ...(prefs || {}) }
  wx.setStorageSync(PREFERENCES_KEY, merged)
  return merged
}

export function clearPreferences() {
  try {
    wx.removeStorageSync(PREFERENCES_KEY)
  } catch (e) {}
}
