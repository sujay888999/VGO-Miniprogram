const app = getApp()
const { getLocation } = require('../../utils/location.js')

Page({
  data: {
    loaded: false,
    location: {
      lat: 0,
      lng: 0
    },
    currentAddress: ''
  },

  async onLoad() {
    await this.initLocation()
    this.setData({ loaded: true })
  },

  async initLocation() {
    try {
      const loc = await getLocation()
      this.setData({
        location: {
          lat: loc.lat,
          lng: loc.lng
        },
        currentAddress: '当前位置附近'
      })
    } catch (e) {
      console.error('getLocation error', e)
    }
  },

  goPublish() {
    // 直接进入乘客端发布页面
    wx.navigateTo({
      url: '/pages/passenger/publish/index'
    })
  },

  goPassenger() {
    // 进入乘客首页（内部再校验身份）
    wx.navigateTo({
      url: '/pages/passenger/index/index'
    })
  },

  goDriver() {
    // 进入司机首页（内部再校验身份）
    wx.navigateTo({
      url: '/pages/driver/index/index'
    })
  },

  onRobotaxiTap() {
    wx.showToast({
      title: '未来自动驾驶维度入口 · 敬请期待',
      icon: 'none'
    })
  }
})
