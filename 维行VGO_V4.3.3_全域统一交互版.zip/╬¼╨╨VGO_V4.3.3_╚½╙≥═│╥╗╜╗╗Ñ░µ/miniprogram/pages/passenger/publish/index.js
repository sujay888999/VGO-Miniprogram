const db = wx.cloud.database()
const app = getApp()
const trips = db.collection('orders_active')

Page({
  data: {
    auth: null,
    loading: false,
    form: {
      start: "",
      end: "",
      datetime: "立即出发",
      remark: ""
    },
    dateOptions: ["立即出发", "今天", "明天", "后天", "选择具体时间"],
    customDate: "",
    startLocation: null,
    startAddress: '',
    endLocation: null,
    endAddress: '',
    from: '',
    fromLocation: null,
    to: '',
    toLocation: null,
    departTime: '',
    remark: '',
    fromAddress: '',
    toAddress: '',
    phone: '',
    phoneNumber: '',
    dateTime: '',
    routeInfo: {
      distance: 0,
      duration: 0
    }
  },

  // 选择出发地位置
  chooseStartLocation() {
    wx.chooseLocation({
      success: (res) => {
        this.setData({ 
          startLocation: res.name,
          fromAddress: res.name,
          fromLocation: {
            lat: res.latitude,
            lng: res.longitude
          }
        });
        // 如果已选择目的地，自动获取路线信息
        if (this.data.toLocation) {
          this.getRoute();
        }
      }
    })
  },

  // 选择目的地位置
  chooseEndLocation() {
    wx.chooseLocation({
      success: (res) => {
        this.setData({ 
          endLocation: res.name,
          toAddress: res.name,
          toLocation: {
            lat: res.latitude,
            lng: res.longitude
          }
        });
        // 如果已选择出发地，自动获取路线信息
        if (this.data.fromLocation) {
          this.getRoute();
        }
      }
    })
  },

  // 从地图组件选择出发地
  onSelectFrom(e) {
    this.setData({
      fromAddress: e.detail.name,
      startLocation: e.detail.name,
      fromLocation: {
        lat: e.detail.location.lat,
        lng: e.detail.location.lng
      }
    });
    // 如果已选择目的地，自动获取路线信息
    if (this.data.toLocation) {
      this.getRoute();
    }
  },

  // 从地图组件选择目的地
  onSelectTo(e) {
    this.setData({
      toAddress: e.detail.name,
      endLocation: e.detail.name,
      toLocation: {
        lat: e.detail.location.lat,
        lng: e.detail.location.lng
      }
    });
    // 如果已选择出发地，自动获取路线信息
    if (this.data.fromLocation) {
      this.getRoute();
    }
  },

  bindDate(e) {
    const { dateOptions } = this.data
    const pickerValue = e.detail.value
    const selected = dateOptions && dateOptions[pickerValue]

    if (selected === "选择具体时间") {
      wx.chooseDate({
        success: res => {
          this.setData({ 
            "form.datetime": res.value,
            departTime: res.value,
            dateTime: res.value
          })
        }
      })
      return
    }

    if (selected) {
      this.setData({ 
        "form.datetime": selected,
        departTime: selected,
        dateTime: selected
      })
    } else if (pickerValue) {
      this.setData({ 
        "form.datetime": pickerValue,
        departTime: pickerValue,
        dateTime: pickerValue
      })
    }
  },

  bindRemark(e) {
    this.setData({ 
      "form.remark": e.detail.value,
      remark: e.detail.value
    })
  },

  onShow() {
    const auth = app.ensureAuth({ requireRole: "passenger" })
    if (!auth) return
    this.setData({ 
      auth,
      phone: auth.phone || app.globalData.phone || '',
      phoneNumber: auth.phone || app.globalData.phone || ''
    })
  },

  // 获取路线信息
  async getRoute() {
    const { fromLocation, toLocation } = this.data;
    if (!fromLocation || !toLocation || !fromLocation.lat || !fromLocation.lng || !toLocation.lat || !toLocation.lng) {
      return;
    }

    const app = getApp();
    const qqmapsdk = app.globalData.qqmapsdk;

    if (!qqmapsdk) {
      console.error('腾讯地图 SDK 未初始化');
      return;
    }

    const that = this;
    qqmapsdk.direction({
      mode: 'driving',
      from: `${fromLocation.lat},${fromLocation.lng}`,
      to: `${toLocation.lat},${toLocation.lng}`,
      success: (res) => {
        if (res.result && res.result.routes && res.result.routes.length > 0) {
          const info = res.result.routes[0];
          const distance = parseFloat((info.distance / 1000).toFixed(1)); // 米转公里
          const duration = Math.round(info.duration / 60); // 秒转分钟
          that.setData({
            'routeInfo.distance': distance,
            'routeInfo.duration': duration
          });
          console.log('路线规划成功:', { distance, duration });
        } else {
          console.warn('路线规划返回数据为空');
          that.setData({
            'routeInfo.distance': 0,
            'routeInfo.duration': 0
        });
      }
      },
      fail: (err) => {
        console.error("路线规划失败：", err);
        that.setData({
          'routeInfo.distance': 0,
          'routeInfo.duration': 0
        });
      }
    });
  },

  // 发布行程
  async publish() {
    const { 
      fromAddress, 
      toAddress, 
      fromLocation, 
      toLocation, 
      phone, 
      remark,
      startLocation,
      endLocation,
      routeInfo,
      phoneNumber,
      dateTime
    } = this.data;
    const startTime = this.data.departTime || this.data.form?.datetime || dateTime || "立即出发";
    const auth = app.globalData.auth;

    if (!auth || !auth.openid) {
      wx.showToast({ title: "请先登录", icon: "none" });
      return;
    }

    if (!fromLocation || !toLocation) {
      wx.showToast({ title: '请选择起终点', icon: 'none' });
      return;
    }

    wx.showLoading({ title: '发布中' });

    try {
      const res = await wx.cloud.callFunction({
        name: 'publishTrip',
        data: {
          fromAddress: fromAddress || startLocation,
          toAddress: toAddress || endLocation,
          fromLocation,
          toLocation,
          startLocation: fromLocation,
          endLocation: toLocation,
          distance: routeInfo?.distance || 0,
          duration: routeInfo?.duration || 0,
          phone: phone || phoneNumber || auth.phone || '',
          passengerPhone: phone || phoneNumber || auth.phone || '',
          remark: remark || this.data.form?.remark || '',
          dateTime: startTime,
          time: startTime,
          status: "pending",
          passengerOpenId: auth.openid
        }
      });

      wx.hideLoading();

      if (res.result && res.result.success) {
        wx.showToast({ title: '发布成功' });
        setTimeout(() => wx.navigateBack(), 1000);
      } else {
        wx.showToast({ title: res.result?.message || '发布失败', icon: 'none' });
      }
    } catch (err) {
      wx.hideLoading();
      console.error('发布失败:', err);
      wx.showToast({ title: '发布失败', icon: 'none' });
    }
  },

  // 兼容旧方法名
  publishTrip() {
    this.publish();
  }
})

