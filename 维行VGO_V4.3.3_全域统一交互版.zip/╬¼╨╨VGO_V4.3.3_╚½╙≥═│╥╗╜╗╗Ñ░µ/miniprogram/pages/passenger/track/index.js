Page({
  data: {
    orderId: '',
    driverLocation: null,
    order: null
  },

  onLoad(e) {
    this.setData({ orderId: e.orderId })
    this.loadOrder()
    this.startWatch()
  },

  onUnload() {
    if (this.timer) clearInterval(this.timer)
  },

  async loadOrder() {
    const res = await wx.cloud.database().collection('orders_active').doc(this.data.orderId).get()
    this.setData({ order: res.data })
  },

  startWatch() {
    this.timer = setInterval(async () => {
      const res = await wx.cloud.database().collection('orders_active').doc(this.data.orderId).get()
      this.setData({ driverLocation: res.data.driverLocation })
    }, 3000)
  }
})

