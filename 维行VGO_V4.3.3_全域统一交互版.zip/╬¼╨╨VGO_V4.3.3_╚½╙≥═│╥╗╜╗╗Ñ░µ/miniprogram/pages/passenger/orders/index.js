const db = wx.cloud.database();
const app = getApp();
const { formatAddress, formatStatus, normalizeStatus } = require('../../../utils/orderFormatter.js');

Page({
  data: {
    list: []
  },

  onShow() {
    this.loadOrders();
  },

  // 获取乘客订单
  loadOrders() {
    const auth = app.globalData.auth;
    if (!auth || !auth.openid) {
      console.warn('未登录，无法加载订单');
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }

    wx.showLoading({ title: '加载中...' });

    db.collection('orders_active')
      .where({ passengerOpenId: auth.openid })
      .orderBy('createTime', 'desc')
      .get()
      .then(res => {
        const list = res.data.map(order => {
          const hasBids = Array.isArray(order.bids) && order.bids.length > 0;

          // 使用统一的状态映射（方案 A）
          const normalizedStatus = normalizeStatus(order.status);
          let statusLabel = formatStatus(normalizedStatus);

          // 统一格式化地址显示
          const displayOrigin = formatAddress(order.origin || order.fromAddress || order.start);
          const displayDestination = formatAddress(order.destination || order.toAddress || order.end);

          return {
            ...order,
            status: normalizedStatus, // 更新为标准状态
            origin: displayOrigin,
            destination: displayDestination,
            statusLabel,
            hasBids
          };
        });

        this.setData({ list });
      })
      .catch(err => {
        console.error('订单加载失败:', err);
        wx.showToast({ title: '加载失败', icon: 'none' });
      })
      .finally(() => wx.hideLoading());
  },

  goDetail(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/passenger/orderDetail/index?id=${id}`
    });
  }
});