const app = getApp()
const db = wx.cloud.database()

Page({
  data: {
    auth: null,
    avatarUploading: false
  },

  async onShow() {
    const auth = app.ensureAuth({ requireRole: "passenger" })
    if (!auth) return
    await this.refreshProfile(auth)
  },

  goPublish() {
    wx.navigateTo({ url: "/pages/passenger/publish/index" })
  },

  goMyOrders() {
    wx.navigateTo({ url: "/pages/passenger/orders/index" })
  },

  async refreshProfile(baseAuth) {
    try {
      const res = await db.collection("users").where({
        _openid: baseAuth.openid
      }).limit(1).get()
      const userProfile = res.data?.[0] || {}
      const merged = {
        ...baseAuth,
        avatar: userProfile.avatar || baseAuth.avatar || "/images/default-avatar.png"
      }
      this.setData({ auth: merged })
      app.saveAuth(merged)
    } catch (err) {
      console.error("refreshProfile passenger failed", err)
      this.setData({ auth: baseAuth })
    }
  },

  async onAvatarTap() {
    if (this.data.avatarUploading) return
    const auth = this.data.auth || app.ensureAuth({ requireRole: "passenger" })
    if (!auth) return
    try {
      const filePath = await this.chooseAvatarFile()
      if (!filePath) return
      this.setData({ avatarUploading: true })
      await app.uploadAvatar(filePath)
      const latestAuth = app.ensureAuth({ requireRole: "passenger" }) || auth
      await this.refreshProfile(latestAuth)
      wx.showToast({ title: "头像已更新", icon: "success" })
    } catch (err) {
      console.error("update passenger avatar failed", err)
      wx.showToast({ title: "上传失败", icon: "none" })
    } finally {
      this.setData({ avatarUploading: false })
    }
  },

  chooseAvatarFile() {
    return new Promise((resolve, reject) => {
      const handleSuccess = res => {
        const path = res?.tempFiles?.[0]?.tempFilePath || res?.tempFilePaths?.[0]
        if (path) {
          resolve(path)
        } else {
          reject(new Error("NO_FILE"))
        }
      }
      const handleFail = err => reject(err || new Error("CANCELLED"))

      if (wx.chooseMedia) {
        wx.chooseMedia({
          count: 1,
          mediaType: ["image"],
          success: handleSuccess,
          fail: handleFail
        })
      } else {
        wx.chooseImage({
          count: 1,
          success: handleSuccess,
          fail: handleFail
        })
      }
    })
  },

  onLogout() {
    wx.showModal({
      title: "提示",
      content: "确定退出登录？",
      success: res => { if (res.confirm) app.logout() }
    })
  },

  // 乘客偏好设置
  goPreferences() {
    wx.navigateTo({
      url: '/pages/settings/preferences/index'
    })
  },

  // 账号与安全
  goAccountSecurity() {
    wx.navigateTo({
      url: '/pages/settings/account/index'
    })
  },

  // 法律条款及隐私政策
  goLegal() {
    wx.navigateTo({
      url: '/pages/settings/legal/index'
    })
  },

})

