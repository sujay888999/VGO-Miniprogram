const db = wx.cloud.database();
const app = getApp();

Page({
  data: {
    orderId: '',
    order: null,
    bids: []
  },

  onLoad(options) {
    const orderId = options.id || options.orderId || '';
    if (!orderId) {
      wx.showToast({ title: '订单ID缺失', icon: 'none' });
      setTimeout(() => wx.navigateBack(), 800);
      return;
    }
    this.setData({ orderId });
    this.loadOrder();
  },

  async loadOrder() {
    wx.showLoading({ title: '加载中...' });
    try {
      const res = await db.collection('orders_active').doc(this.data.orderId).get();
      const order = res.data || null;
      const rawBids = Array.isArray(order?.bids) ? order.bids : [];

      const bids = rawBids.map(b => ({
        bidId: b._id,
        driverOpenId: b.driverOpenId,
        driverPhone: b.driverPhone || '',
        price: b.price,
        createTime: b.createTime
      }));

      this.setData({
        order,
        bids
      });
    } catch (err) {
      console.error('loadOrder error:', err);
      wx.showToast({ title: '加载失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  onBidTap(e) {
    const { bidindex } = e.currentTarget.dataset;
    const bid = this.data.bids[bidindex];
    if (!bid) return;

    wx.showModal({
      title: '确认选择该司机？',
      content: `报价金额：¥${bid.price}`,
      confirmText: '确认',
      cancelText: '再看看',
      success: async (res) => {
        if (res.confirm) {
          await this.confirmDriver(bid);
        }
      }
    });
  },

  async confirmDriver(bid) {
    wx.showLoading({ title: '确认中...' });
    try {
      const res = await wx.cloud.callFunction({
        name: 'confirmDriver',
        data: {
          orderId: this.data.orderId,
          bidId: bid.bidId || bid._id,
          driverOpenId: bid.driverOpenId
        }
      });

      wx.hideLoading();

      if (res.result && res.result.success) {
        wx.showToast({ title: '确认成功', icon: 'success' });
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      } else {
        wx.showToast({
          title: res.result?.message || '确认失败',
          icon: 'none'
        });
      }
    } catch (err) {
      wx.hideLoading();
      console.error('confirmDriver error:', err);
      wx.showToast({ title: '服务器错误', icon: 'none' });
    }
  }
});
