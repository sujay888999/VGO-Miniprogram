// 确认云开发初始化
if (!wx.cloud) {
  wx.cloud.init();
}

const db = wx.cloud.database();
const app = getApp();
const { formatAddress, formatDate, formatDistance, formatDuration, formatStatus, normalizeStatus } = require('../../../utils/orderFormatter.js');

Page({
  data: {
    orderId: '',
    id: '',
    order: null,
    statusText: '',
    displayFromAddress: '',
    displayToAddress: '',
    displayDistance: '',
    displayDuration: '',
    // 司机信息
    driverAvatar: '',
    driverCarModel: '',
    driverCarNumber: '',
    bids: [],
    bidList: [], // 新增 bidList 数组存储全部报价数据
    sortType: 'default', // 'default' | 'price' | 'score' | 'distance'
    statusLabel: '',
    statusClass: '',
    routeInfo: null, // { distanceKm, durationMin }
    loadingBids: false,
    hasBids: false,
    selectedBid: null
  },

  onLoad(options) {
    console.log('orderDetail onLoad options:', options);
    
    // 检查登录状态
    const auth = app.ensureAuth ? app.ensureAuth({ requireRole: 'passenger' }) : null;
    if (!auth) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      setTimeout(() => {
        wx.navigateTo({ url: '/pages/login/login?role=passenger' });
      }, 800);
      return;
    }

    const { id } = options;
    this.setData({ orderId: id || '' });
    
    if (id && this.loadDetail) {
      this.loadDetail();
      this.loadBids();
    } else if (!id) {
      wx.showToast({ title: '订单信息缺失', icon: 'none' });
      setTimeout(() => wx.navigateBack(), 800);
    }
  },

  onShow() {
    if (this.orderId) {
      this.loadDetail();
      this.loadBids();
      if (typeof this.fetchRoute === 'function') {
        this.fetchRoute();
      }
    }
    
    // 自动取消过期订单（30分钟前创建的订单）
    if (this.data.order) {
      const createTime = new Date(this.data.order.createTime);
      const diff = Date.now() - createTime.getTime();
      
      // 如果订单超过30分钟且状态不是已取消，自动取消
      if (diff > 30 * 60 * 1000 && this.data.order.status !== 'cancelled') {
        wx.cloud.callFunction({
          name: 'updateOrderStatus',
          data: {
            orderId: this.data.order._id,
            status: 'cancelled'
          }
        }).then(() => {
          console.log('✅ 自动取消过期订单:', this.data.order._id);
          this.loadDetail(); // 重新加载订单详情
        }).catch(err => {
          console.error('❌ 自动取消订单失败:', err);
        });
      }
    }
  },

  // 统一格式化订单显示
  formatOrderForView(order) {
    if (!order) return

    // 优先使用 fromAddress.name / toAddress.name，统一使用 formatAddress 格式化
    const displayFromAddress = formatAddress(
      order.fromAddress || order.origin || order.startLocation || order.start
    ) || '未知起点'

    const displayToAddress = formatAddress(
      order.toAddress || order.destination || order.endLocation || order.end
    ) || '未知终点'

    const displayDistance = formatDistance(order.distance || order.distanceKm) || '未知距离'
    const displayDuration = formatDuration(order.duration || order.durationMin) || '未知时长'

    // 使用统一的状态映射（方案 A）
    const { formatStatus, normalizeStatus } = require('../../../utils/orderFormatter.js');
    const normalizedStatus = normalizeStatus(order.status);
    const statusText = formatStatus(normalizedStatus);
    
    // 更新订单状态为标准状态
    order.status = normalizedStatus;

    this.setData({
      order,
      statusText,
      displayFromAddress,
      displayToAddress,
      displayDistance,
      displayDuration,
      driverAvatar: order.driverAvatar || '',
      driverCarModel: order.driverCarModel || '',
      driverCarNumber: order.driverCarNumber || '',
    })
  },

  async loadDetail() {
    wx.showLoading({ title: '加载中...' });
    try {
      const res = await db.collection('orders_active').doc(this.data.orderId).get();
      const order = res.data;

      // 增强容错：设置订单数据，防止 undefined 报错
      this.setData({
        order: {
          ...order,
          distance: order.distance || 0,
          duration: order.duration || 0,
          autoPrice: order.autoPrice || null,
          status: order.status || 'pending',
        }
      });

      // 使用统一格式化函数
      this.formatOrderForView(order);

      // 在成功加载订单后添加：加载报价列表
      this.loadBids();

      // 订单信息加载完成后，获取路线信息
      const start = order?.origin || order?.start; // 兼容旧字段
      const end = order?.destination || order?.end; // 兼容旧字段
      console.log('Route Start/End:', start, end);
      
      if (typeof this.fetchRoute === 'function') {
        this.fetchRoute();
      }
    } catch (err) {
      console.error('loadDetail error:', err);
      wx.showToast({ title: '订单加载失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  // 新增调用 getBids 获取司机报价
  async loadBids() {
    const orderId = this.data.order?._id || this.data.orderId;
    if (!orderId) {
      console.log("loadBids: orderId 为空");
      return;
    }

    console.log("loadBids: 开始加载报价，orderId =", orderId);

    try {
      const res = await wx.cloud.callFunction({
        name: 'getBids',
        data: {
          orderId: orderId,
          sortBy: this.data.sortType || 'composite'
        }
      });

      console.log("getBids 返回:", res.result);

      if (res.result && res.result.success) {
        const bids = res.result.data || [];
        // 保存所有报价到 bidList 数组
        this.setData({
          bids: bids,
          bidList: bids, // 新增 bidList 数组存储全部报价数据
          hasBids: bids.length > 0
        });
        console.log("loadBids: 报价列表已更新，数量 =", bids.length);
      } else {
        console.warn('loadBids: 未获取到报价数据');
        this.setData({
          bids: [],
          bidList: [],
          hasBids: false
        });
      }
    } catch (err) {
      console.error('loadBids error:', err);
      wx.showToast({ title: '获取报价失败', icon: 'none' });
      this.setData({
        bids: [],
        bidList: [],
        hasBids: false
      });
    }
  },

  // 排序报价列表
  sortBids(e) {
    const sortType = e.currentTarget?.dataset?.type || e;
    this.setData({ sortType });
    
    // 重新调用 getBids 获取排序后的报价
    this.loadBids();
  },

  async loadBidsOld(orderId) {
    const targetOrderId = orderId || this.data.orderId;
    if (!targetOrderId) {
      console.log("loadBids: orderId 为空");
      return;
    }

    console.log("loadBids: 开始加载报价，orderId =", targetOrderId);

    this.setData({ loadingBids: true });

    try {
      // 调用 getBids 云函数获取报价列表
      const res = await wx.cloud.callFunction({
        name: 'getBids',
        data: { orderId: targetOrderId }
      });

      if (!res.result || !res.result.success) {
        throw new Error(res.result?.message || '获取报价失败');
      }

      const bids = res.result.data || [];

      if (bids.length === 0) {
        this.setData({
          bids: [],
          hasBids: false,
          loadingBids: false
        });
        return;
      }

      // 为每个 bid 补充司机信息
      const enhancedBids = await Promise.all(
        bids.map(async (bid) => {
          try {
            // 尝试通过 _openid 查询，如果 users 集合有自定义 openid 字段则使用 where
            // 否则尝试直接查询（如果 driverOpenId 就是 _openid）
            let driverUser = null;
            
            try {
              // 方法1: 尝试使用 where 查询（如果 users 集合有 openid 字段）
              const userRes = await db.collection('users')
                .where({
                  openid: bid.driverOpenId,
                  role: 'driver'
                })
                .get();

              if (userRes.data && userRes.data.length > 0) {
                driverUser = userRes.data[0];
              }
            } catch (err1) {
              // 方法2: 如果 where 失败，尝试查询所有 driver 然后过滤
              try {
                const allDriversRes = await db.collection('users')
                  .where({ role: 'driver' })
                  .get();
                
                driverUser = allDriversRes.data.find(u => u._openid === bid.driverOpenId || u.openid === bid.driverOpenId);
              } catch (err2) {
                console.warn('查询司机信息失败，使用默认值:', err2);
              }
            }

            return {
              ...bid,
              driverAvatar: driverUser?.avatar || '/images/default-avatar.png',
              driverPhone: driverUser?.phone || bid.driverPhone || '未知',
              driverRating: driverUser?.rating ?? 4.8,
              driverCompletedTrips: driverUser?.completedTrips ?? 0
            };
          } catch (err) {
            console.error('查询司机信息失败:', err);
            return {
              ...bid,
              driverAvatar: '/images/default-avatar.png',
              driverPhone: bid.driverPhone || '未知',
              driverRating: 4.8,
              driverCompletedTrips: 0
            };
          }
        })
      );

      // 使用统一字段名
      const formattedBids = enhancedBids.map(bid => ({
        ...bid,
        price: bid.price || bid.bidPrice || 0,
        driverScore: bid.driverScore || bid.driverRating || 4.8,
        distanceKm: bid.distanceKm || 0
      }));

      // 默认综合排序
      this.sortBids('default', formattedBids);

      console.log("loadBids: 报价列表已更新，数量 =", formattedBids.length);
    } catch (err) {
      console.error('loadBids error:', err);
      wx.showToast({ title: '获取报价失败', icon: 'none' });
      this.setData({
        bids: [],
        hasBids: false,
        loadingBids: false
      });
    }
  },

  
  // 选择司机
  async onSelectDriver(e) {
    console.log('选择TA 事件触发, dataset =', e.currentTarget.dataset);

    const dataset = e.currentTarget.dataset || {};
    // 从 data.order / data.orderId / dataset.orderId 多路兜底取订单 id
    const order = this.data.order || {};
    let orderId =
      dataset.orderId ||
      this.data.orderId ||
      order._id ||
      order.id ||
      '';

    let bidId = dataset.bidId || dataset.id || '';
    let driverOpenId = dataset.driverOpenId || dataset.openid || dataset.openId || '';
    let driverPhone = dataset.driverPhone || dataset.phone || '';

    // 兜底：如果前端 data-* 未带全，则从 bids / bidList 中补齐
    if (!bidId || !driverOpenId || !driverPhone) {
      const allBids = this.data.bids || this.data.bidList || [];
      if (allBids && allBids.length > 0) {
        // 如果没有 bidId，就取第一个；有 bidId 就匹配对应那条
        let targetBid = null;
        if (bidId) {
          targetBid = allBids.find(b => b._id === bidId || b.id === bidId);
        }
        if (!targetBid) {
          targetBid = allBids[0];
        }
        if (targetBid) {
          bidId = bidId || targetBid._id || targetBid.id || '';
          driverOpenId = driverOpenId || targetBid.driverOpenId || targetBid.openid || targetBid.openId || '';
          driverPhone = driverPhone || targetBid.driverPhone || targetBid.phone || '';
        }
      }
    }

    // 再兜一次 orderId，避免 undefined
    if (!orderId && this.data.order && this.data.order._id) {
      orderId = this.data.order._id;
    }

    console.log('选择司机参数（兜底后）：', { orderId, bidId, driverOpenId, driverPhone });

    if (!orderId || !bidId || !driverOpenId) {
      wx.showToast({
        title: '参数缺失',
        icon: 'none'
      });
      return;
    }

    wx.showLoading({ title: '确认中...' });

    try {
      // 1）先调用 selectDriver，写入订单选中的报价（强制传入 orderId, driverOpenId, bidId）
      const res = await wx.cloud.callFunction({
        name: 'selectDriver',
        data: { 
          orderId,
          bidId,
          driverOpenId,
          driverPhone
        }
      });

      console.log('selectDriver 云函数返回：', res);

      const result = res.result || {};
      if (!result.success) {
        wx.showToast({
          title: result.message || '选司机失败',
          icon: 'none'
        });
        return;
      }

      wx.showToast({
        title: '已向司机发单',
        icon: 'success'
      });

      // 重新加载订单数据以更新显示
      await this.loadDetail();
      await this.loadBids();

      // 选择司机成功后，跳转进行中订单页（如果存在），否则留在当前页
      const ongoingOrderPath = '/pages/passenger/orders/index?tab=ongoing';
      setTimeout(() => {
        wx.navigateTo({
          url: ongoingOrderPath,
          fail: () => {
            this.loadDetail();
          }
        });
      }, 1200);
    } catch (err) {
      console.error('选择司机流程异常：', err);
      wx.showToast({ 
        title: '操作失败',
        icon: 'none' 
      });
    } finally {
      wx.hideLoading();
    }
  },

  // 获取订单详情（loadDetail 的别名）
  getOrderDetail() {
    this.loadDetail();
  },

  // 联系司机（暂时用真实手机号，后面可接入虚拟号）
  onCallDriver() {
    const { order } = this.data
    if (!order || !order.driverPhone) {
      wx.showToast({ title: '暂无司机电话', icon: 'none' })
      return
    }
    wx.makePhoneCall({
      phoneNumber: order.driverPhone,
    })
  },

  // 取消订单
  onCancelOrder() {
    const { order } = this.data
    if (!order || !order._id) return

    wx.showModal({
      title: '取消订单',
      content: '确认要取消当前订单吗？',
      success: (res) => {
        if (!res.confirm) return

        wx.showLoading({ title: '取消中...' })
        wx.cloud
          .callFunction({
            name: 'updateOrderStatus',
            data: {
              orderId: order._id,
              status: 'cancelled',
            },
          })
          .then((resp) => {
            const result = resp.result || {}
            if (result.success) {
              wx.showToast({ title: '已取消', icon: 'success' })
              // 更新本地状态
              this.formatOrderForView({
                ...order,
                status: 'cancelled',
              })
            } else {
              wx.showToast({
                title: result.message || '取消失败',
                icon: 'none',
              })
            }
          })
          .catch((err) => {
            console.error('取消订单失败:', err)
            wx.showToast({ title: '服务器错误', icon: 'none' })
          })
          .finally(() => {
            wx.hideLoading()
          })
      },
    })
  },

  async fetchRoute() {
    const order = this.data.order;
    if (!order) {
      console.warn('fetchRoute: 订单数据不存在');
      return;
    }

    // 获取位置信息，优先使用新字段，兼容旧字段
    let fromLocation = order.fromLocation || order.startLocation;
    let toLocation = order.toLocation || order.endLocation;

    // 如果还没有，尝试从订单地址解析（这里可能需要其他方式获取坐标）
    if (!fromLocation || !toLocation) {
      console.warn('fetchRoute: 缺少位置坐标信息，跳过路线计算');
      return;
    }

    // 确保位置对象包含 lat 和 lng
    if (!fromLocation.lat || !fromLocation.lng || !toLocation.lat || !toLocation.lng) {
      console.warn('fetchRoute: 位置参数格式不正确');
      return;
    }

    wx.showLoading({ title: '获取路线中...' });

    try {
      const res = await wx.cloud.callFunction({
        name: 'getRoute',
        data: {
          from: `${fromLocation.lng},${fromLocation.lat}`,
          to: `${toLocation.lng},${toLocation.lat}`
        }
      });

      wx.hideLoading();

      if (res.result && res.result.success && res.result.data) {
        const { distance, duration, km, minutes } = res.result.data;
        const distanceKm = parseFloat(km || (distance / 1000).toFixed(1));
        const durationMin = minutes || Math.round(duration / 60);
        // 更新路线信息到订单对象，然后重新格式化
        const updatedOrder = {
          ...this.data.order,
          distance: distance || distanceKm * 1000,
          duration: duration || durationMin,
          distanceKm: distanceKm,
          durationMin: durationMin
        }
        this.formatOrderForView(updatedOrder)
        console.log('路线规划成功:', { distanceKm, durationMin });
      } else {
        console.warn('路线规划返回数据为空');
        // 更新订单对象，然后重新格式化
        const updatedOrder = {
          ...this.data.order,
          distance: 0,
          duration: 0,
          distanceKm: 0,
          durationMin: 0
        }
        this.formatOrderForView(updatedOrder)
      }
    } catch (err) {
      wx.hideLoading();
      console.error("路线规划失败：", err);
      // 更新订单对象，然后重新格式化
      const updatedOrder = {
        ...this.data.order,
        distance: 0,
        duration: 0,
        distanceKm: 0,
        durationMin: 0
      }
      this.formatOrderForView(updatedOrder)
    }
  }
});