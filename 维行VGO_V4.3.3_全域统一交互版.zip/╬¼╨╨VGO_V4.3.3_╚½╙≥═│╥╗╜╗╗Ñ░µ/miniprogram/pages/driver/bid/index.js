const app = getApp();
const db = wx.cloud.database();

Page({
  data: {
    orderId: '',
    order: null,
    bidPrice: ''
  },

  onLoad(options) {
    const orderId = options.id || '';
    if (!orderId) {
      wx.showToast({ title: '订单ID缺失', icon: 'none' });
      setTimeout(() => wx.navigateBack(), 800);
      return;
    }
    this.setData({ orderId });
    this.loadOrder();
  },

  async loadOrder() {
    try {
      const res = await db.collection('orders_active').doc(this.data.orderId).get();
      this.setData({ order: res.data });
    } catch (err) {
      console.error('loadOrder error:', err);
      wx.showToast({ title: '加载失败', icon: 'none' });
    }
  },

  onBidInput(e) {
    this.setData({ bidPrice: e.detail.value });
  },

  async submitBid() {
    const { bidPrice, orderId } = this.data;
    const openid = app.globalData.openid || wx.getStorageSync('openid');
    
    if (!openid) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      wx.navigateTo({
        url: '/pages/login/login'
      });
      return;
    }

    const auth = { openid, phone: app.globalData.phone || wx.getStorageSync('phone') || '' };

    if (!bidPrice || !Number(bidPrice) || Number(bidPrice) <= 0) {
      wx.showToast({ title: '请输入有效报价', icon: 'none' });
      return;
    }

    wx.showLoading({ title: '提交中...' });

    try {
      // 先调用 createBid 创建报价
      const bidRes = await wx.cloud.callFunction({
        name: 'createBid',
        data: {
          orderId,
          driverOpenId: auth.openid,
          driverPhone: auth.phone || '',
          bidPrice: Number(bidPrice),
          distance: this.data.order?.distance || 0,
          duration: this.data.order?.duration || 0
        }
      });

      if (!bidRes.result || !bidRes.result.success) {
        wx.hideLoading();
        wx.showToast({
          title: bidRes.result?.message || '报价失败',
          icon: 'none'
        });
        return;
      }

      // createBid 已经更新状态为 bidPending，driverLocked 保持 false，不需要再次调用 updateOrderStatus
      wx.hideLoading();
      wx.showToast({ title: '报价成功', icon: 'success' });
      setTimeout(() => {
        wx.navigateBack();
      }, 1200);
    } catch (err) {
      wx.hideLoading();
      console.error('submitBid error:', err);
      wx.showToast({ title: '服务器错误', icon: 'none' });
    }
  }
});

