Page({
  data: {
    orderId: '',
    order: null
  },

  onLoad(e) {
    this.setData({ orderId: e.orderId })
    this.loadOrder()
  },

  loadOrder() {
    wx.cloud.callFunction({
      name: 'order_flow',
      data: { action: 'getOrderDetail', orderId: this.data.orderId }
    }).then(res => {
      const result = res.result || {}
      if (result.success) {
        this.setData({ order: result.data })
      }
    })
  },

  startPickup() {
    wx.cloud.callFunction({
      name: 'order_flow',
      data: {
        action: 'startPickup',
        data: {
          orderId: this.data.orderId,
          driverOpenId: this.data.order?.acceptedDriver?.driverOpenId || wx.getStorageSync('openid')
        }
      }
    }).then(res => {
      const r = res.result || {}
      if (r.success) {
        wx.showToast({ title: '开始接驾', icon: 'success' })
        wx.navigateTo({
          url: `/pages/driver/navigate/index?orderId=${this.data.orderId}`
        })
      } else {
        wx.showToast({ title: r.message || '失败', icon: 'none' })
      }
    }).catch(err => {
      console.error('startPickup error:', err)
      wx.showToast({ title: '操作失败', icon: 'none' })
    })
  }
})

