Page({
  data: {
    income: {}
  },

  onShow() {
    this.loadIncome()
  },

  async loadIncome() {
    const res = await wx.cloud.callFunction({
      name: 'driver_income'
    })
    if (res.result.success) {
      this.setData({ income: res.result.data })
    }
  }
})

