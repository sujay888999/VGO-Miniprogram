const db = wx.cloud.database()
const ordersCollection = db.collection('orders_active')

Page({
  data: {
    orders: []
  },

  onShow() {
    this.loadOrders()
  },

  onPullDownRefresh() {
    this.loadOrders().finally(() => wx.stopPullDownRefresh())
  },

  async loadOrders() {
    wx.showLoading({ title: '加载中...' })

    try {
      const statusList = ['waitingDriverBid', 'waiting', 'bidding']
      const all = []

      for (const s of statusList) {
        const res = await ordersCollection.where({ status: s })
          .orderBy('createTime', 'desc')
          .limit(50)
          .get()
        all.push(...res.data)
      }

      const map = new Map(all.map(o => [o._id, o]))
      let orders = Array.from(map.values())

      // 获取当前司机 openid
      const openid = wx.getStorageSync('openid')

      // 过滤掉司机已报价的订单
      orders = orders.filter(order => {
        if (!openid || !order.bids) return true
        return !order.bids.some(bid => bid.driverOpenId === openid)
      })

      // ⭐ 获取司机定位用于计算距离排序
      const driverLocation = wx.getStorageSync('location') || {}

      orders = orders.map(o => {
        const score = Number(o.passengerScore || 4.5) // 默认 4.5 分
        const dist = Number(o.distanceKm || o.distance || 999)
        const timeScore = o.createTime ? new Date(o.createTime).getTime() : 0

        // 综合权重算法
        o.weight = score * 3 + (10 - dist) * 2 + timeScore / 1000000000000
        return o
      })

      // 按权重从高到低排序
      orders.sort((a, b) => b.weight - a.weight)

      this.setData({ orders })
      wx.hideLoading()

      if (!orders.length) {
        wx.showToast({ title: '暂无可用订单', icon: 'none' })
      }
    } catch (err) {
      wx.hideLoading()
      wx.showToast({ title: '加载失败', icon: 'none' })
      console.error('订单加载失败:', err)
    }
  },

  goToDetail(e) {
    const id = e.currentTarget.dataset.id
    if (!id) {
      wx.showToast({ title: '订单异常', icon: 'none' })
      return
    }
    wx.navigateTo({
      url: `/pages/driver/orderDetail/index?orderId=${id}`
    })
  }
})
