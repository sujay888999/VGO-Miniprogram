const db = wx.cloud.database()
const app = getApp()

Page({
  data: {
    orders: []
  },

  onShow() {
    this.loadMyOrders()
  },

  // 跳转到订单详情页
  goToDetail(e) {
    const { id } = e.currentTarget.dataset
    console.log("跳转订单 id：", id)
    wx.navigateTo({
      url: `/pages/driver/orderDetail/index?orderId=${id}`
    })
  },

  loadMyOrders() {
    const openid = app.globalData.openid || wx.getStorageSync('openid');
    
    if (!openid) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      wx.navigateTo({
        url: '/pages/login/login'
      });
      return;
    }

    wx.showLoading({ title: '加载中...' })

    db.collection('orders_active')
      .where({
        driverOpenId: openid,
        status: db.command.in(["bidPending", "accepted", "going"])
      })
      .orderBy("createTime", "desc")
      .get()
      .then(res => {
        console.log("🚕我的订单列表：", res.data)
        wx.hideLoading()
        this.setData({ orders: res.data })
      })
      .catch(err => {
        wx.hideLoading()
        console.error("❌获取我的订单失败", err)
        wx.showToast({ title: '加载失败', icon: 'none' })
      })
  }
})

