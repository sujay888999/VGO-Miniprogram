const db = wx.cloud.database()
const app = getApp()
const { formatAddress, formatDate, formatDistance, formatDuration } = require('../../../utils/orderFormatter.js')

Page({
  data: {
    orders: []
  },

  onShow() {
    // 加载我的订单列表
    this.loadMyOrders()
  },

  // 加载我的订单列表：基于条件 where("bids.driverOpenId" == 当前driver openid)
  async loadMyOrders() {
    const openid = app.globalData.openid || wx.getStorageSync('openid');
    
    if (!openid) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      wx.navigateTo({
        url: '/pages/login/login'
      });
      return;
    }

    const driverOpenId = openid
    if (!driverOpenId) {
      wx.showToast({ title: '获取用户信息失败', icon: 'none' })
      return
    }

    wx.showLoading({ title: '加载中...' })

    try {
      // 调用云函数 getOrders，scene='driverMine'
      // 云函数内部会基于条件查询该司机在 bids 数组中有报价的订单
      const res = await wx.cloud.callFunction({
        name: 'getOrders',
        data: {
          scene: 'driverMine',
          driverOpenId: driverOpenId
        }
      })

      if (res.result && res.result.success) {
        const ordersList = res.result.data || []
        
        // 预处理订单列表的显示字段，格式化地址为字符串（标准规范要求）
        const formattedOrders = ordersList.map(order => {
          // 使用 myBid 字段（从云函数 getOrders 返回）
          const myBid = order.myBid;
          const bidStatus = myBid?.status || order.bidStatus;
          const bidPrice = myBid?.price || order.bidPrice || 0;
          
          // 生成状态文本
          let statusText = order.statusText;
          if (!statusText) {
            if (bidStatus === 'pending') {
              statusText = '等待乘客选择';
            } else if (bidStatus === 'selected') {
              statusText = '已被乘客选中';
            } else {
              statusText = '未知状态';
            }
          }
          
          return {
            ...order,
            displayFrom: typeof order.fromAddress === 'string' 
              ? order.fromAddress 
              : (order.fromAddress?.name || order.fromAddress?.address || '未知起点'),
            displayTo: typeof order.toAddress === 'string' 
              ? order.toAddress 
              : (order.toAddress?.name || order.toAddress?.address || '未知终点'),
            displayTime: order.dateTime || order.datetime || order.createTime || '未知',
            statusText: statusText,
            bidStatus: bidStatus,
            bidPrice: bidPrice
          }
        })
        
        wx.hideLoading()
        this.setData({ orders: formattedOrders })
        console.log("🚕我的订单列表：", formattedOrders)
      } else {
        throw new Error(res.result?.message || '获取订单失败')
      }
    } catch (err) {
      wx.hideLoading()
      console.error("❌获取我的订单失败", err)
      wx.showToast({ title: '加载失败', icon: 'none' })
    }
  },

  // 跳转到订单详情
  goToDetail(e) {
    const orderId = e.currentTarget.dataset.id || e.currentTarget.dataset.order?._id
    if (!orderId) {
      wx.showToast({ title: '订单ID缺失', icon: 'none' })
      return
    }
    // 订单详情页已删除
    wx.showToast({ title: '订单详情页已移除', icon: 'none' })
    // wx.navigateTo({
    //   url: `/pages/driver/orderDetail/index?orderId=${orderId}`
    // })
  }
})

