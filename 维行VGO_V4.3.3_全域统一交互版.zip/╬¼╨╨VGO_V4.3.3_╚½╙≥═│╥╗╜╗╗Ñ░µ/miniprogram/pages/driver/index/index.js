const db = wx.cloud.database()

Page({
  data: {
    driver: {},
    todayOrders: 0,
    todayIncome: 0,
    online: false
  },

  onShow() {
    this.loadDriver()
    this.loadTodayStats()
    this.setData({ online: wx.getStorageSync('driver_online') || false })
  },

  async loadDriver() {
    const openid = wx.getStorageSync('openid')
    const res = await db.collection('drivers').where({ openid }).get()
    this.setData({ driver: res.data[0] || {} })
  },

  async loadTodayStats() {
    // TODO 未来改成真实统计
    this.setData({
      todayOrders: 5,
      todayIncome: 132.8
    })
  },

  toggleOnline(e) {
    this.setData({ online: e.detail.value })
    wx.setStorageSync('driver_online', e.detail.value)
  },

  goHall(e) {
    console.log('goHall 被调用', e)
    wx.navigateTo({
      url: '/pages/driver/orderHall/index',
      success: () => {
        console.log('跳转成功')
      },
      fail: (err) => {
        console.error('跳转失败', err)
        wx.showToast({
          title: '跳转失败：' + (err.errMsg || '未知错误'),
          icon: 'none',
          duration: 2000
        })
      }
    })
  }
})
