const db = wx.cloud.database()
const app = getApp()

Page({
  data: {
    driver: {},
    serviceScore: 5.0,
    todayOrders: 0,
    todayIncome: 0,
    online: false
  },

  onShow() {
    const openid = app.globalData.openid || wx.getStorageSync('openid');
    
    if (!openid) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      wx.navigateTo({
        url: '/pages/login/login'
      });
      return;
    }

    this.initDriver()
    this.loadTodayStats()
    const online = wx.getStorageSync('driver_online') || false
    this.setData({ online })
  },

  async initDriver() {
    const auth = app.loadAuthFromStorage ? app.loadAuthFromStorage() : null
    const openid = (auth && auth.openid) || wx.getStorageSync('openid')
    if (!openid) return

    try {
      const res = await db.collection('drivers').where({ openid }).limit(1).get()
      if (res.data && res.data.length) {
        const driver = res.data[0]
        this.setData({
          driver,
          serviceScore: driver.serviceScore || driver.rating || 5.0
        })
      } else {
        this.setData({
          driver: { name: '维行VGO认证司机' },
          serviceScore: 5.0
        })
      }
    } catch (err) {
      console.error('加载司机信息失败', err)
    }
  },

  async loadTodayStats() {
    const auth = app.loadAuthFromStorage ? app.loadAuthFromStorage() : null
    const openid = (auth && auth.openid) || wx.getStorageSync('openid')
    if (!openid) return

    const _ = db.command
    const start = new Date()
    start.setHours(0, 0, 0, 0)

    try {
      const res = await db.collection('orders_active')
        .where({
          driverOpenId: openid,
          createTime: _.gte(start)
        })
        .get()

      const orders = res.data || []
      let total = 0
      orders.forEach(o => {
        const price = o.driverPrice || o.price || 0
        total += Number(price) || 0
      })

      this.setData({
        todayOrders: orders.length,
        todayIncome: total.toFixed(1)
      })
    } catch (err) {
      console.error('加载今日订单统计失败', err)
    }
  },

  toggleOnline(e) {
    const online = e.detail.value
    this.setData({ online })
    wx.setStorageSync('driver_online', online)
  },

  goHall() {
    wx.navigateTo({
      url: '/pages/driver/orderHall/index'
    })
  },

  goMyOrders() {
    wx.navigateTo({
      url: '/pages/driver/myOrders/index'
    })
  }
})