Page({
  data: {
    unitPrice: 2.5
  },

  onLoad() {
    // 加载保存的单价
    const savedPrice = wx.getStorageSync('unitPrice')
    if (savedPrice) {
      this.setData({ unitPrice: savedPrice })
    }
  },

  // PATCH: 允许小数点输入（替换原数字校验）
  onInputPrice(e) {
    const value = e.detail.value
    const valid = value.replace(/[^\d.]/g, "").replace(/^\./, "");
    this.setData({ unitPrice: valid })
  },

  onSave() {
    const { unitPrice } = this.data
    const valueNumber = Number(unitPrice)
    
    if (!valueNumber || valueNumber <= 0) {
      wx.showToast({ title: '请输入有效的单价', icon: 'none' })
      return
    }

    // 保存为 driverUnitPrice（优先）和 unitPrice（兼容）
    wx.setStorageSync('driverUnitPrice', valueNumber)
    wx.setStorageSync('unitPrice', valueNumber)
    wx.showToast({ title: '保存成功', icon: 'success' })
    
    setTimeout(() => {
      wx.navigateBack()
    }, 1500)
  }
})

