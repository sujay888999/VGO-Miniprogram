const db = wx.cloud.database()
const app = getApp()
const { formatAddress, formatDate, formatDistance, formatDuration } = require('../../../utils/orderFormatter.js')

Page({
  data: {
    orderId: '',
    order: null,
    orders: [],
    statusText: '',
    // 预处理后的显示字段
    displayFrom: '',
    displayTo: '',
    displayTime: ''
  },

  onLoad(options) {
    const orderId = options.orderId || ''
    if (orderId) {
      this.setData({ orderId })
    }
  },

  onShow() {
    // 加载我的订单列表
    this.loadMyOrders()
    
    // 如果有单个订单ID，也加载单个订单状态
    if (this.data.orderId) {
      this.loadCurrentOrder()
    }

    if (this._pollTimer) {
      clearInterval(this._pollTimer)
    }

    this._pollTimer = setInterval(() => {
      if (this.data.orderId) {
        this.loadCurrentOrder(true)
      }
      // 定期刷新订单列表
      this.loadMyOrders()
    }, 5000)
  },

  onHide() {
    if (this._pollTimer) {
      clearInterval(this._pollTimer)
      this._pollTimer = null
    }
  },

  onUnload() {
    if (this._pollTimer) {
      clearInterval(this._pollTimer)
      this._pollTimer = null
    }
  },

  // 轮询刷新当前订单状态
  loadCurrentOrder(isSilent = false) {
    const openid = wx.getStorageSync('openid')
    if (!openid) return

    if (!isSilent) {
      wx.showLoading({ title: '加载中...' })
    }

    const db = wx.cloud.database()
    db.collection('orders_active')
      .where({
        driverOpenId: openid,
        status: db.command.in([
          'pending',
          'bidPending',
          'accepted',
          'confirmed',
          'completed',
        ]),
      })
      .orderBy('updateTime', 'desc')
      .limit(1)
      .get()
      .then((res) => {
        const order = res.data && res.data[0]
        if (!order) {
          this.setData({ order: null, statusText: '' })
          return
        }

        // 使用统一的状态映射（方案 A）
        const { formatStatus, normalizeStatus } = require('../../../utils/orderFormatter.js');
        const normalizedStatus = normalizeStatus(order.status);
        
        const statusMap = {
          waitingDriverBid: '等待司机抢单',
          bidding: '司机报价中',
          passengerSelect: '等待乘客选择司机',
          accepted: '司机已接单，待接乘客',
          picking: '司机前往上车点',
          onboard: '乘客已上车',
          tripStarted: '行程进行中',
          completed: '已完成',
          cancelled: '已取消',
        }
        
        // 更新订单状态为标准状态
        order.status = normalizedStatus;

        // 预处理订单显示字段
        const displayFrom = formatAddress(order.origin || order.fromAddress || order.startAddress)
        const displayTo = formatAddress(order.destination || order.toAddress || order.endAddress)
        const displayTime = order.dateTime || order.createTime || '未知'

        this.setData({
          order,
          statusText: statusMap[normalizedStatus] || formatStatus(normalizedStatus) || '',
          displayFrom,
          displayTo,
          displayTime
        })

        // 当状态从 driverBidding 变为 accepted，自动跳转到订单详情
        if (order.status === 'accepted') {
          wx.redirectTo({
            url: `/pages/driver/orderDetail/index?orderId=${order._id}`
          })
        }
      })
      .catch((err) => {
        console.error('loadCurrentOrder error:', err)
      })
      .finally(() => {
        if (!isSilent) wx.hideLoading()
      })
  },

  // 加载我的订单列表：调用云函数 getOrders(scene='driverMine')
  async loadMyOrders() {
    const openid = app.globalData.openid || wx.getStorageSync('openid');
    
    if (!openid) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      wx.navigateTo({
        url: '/pages/login/login'
      });
      return;
    }

    wx.showLoading({ title: '加载中...' })

    try {
      // 调用云函数 getOrders，scene='driverMine'
      const res = await wx.cloud.callFunction({
        name: 'getOrders',
        data: {
          scene: 'driverMine',
          driverOpenId: driverOpenId
        }
      })

      if (res.result && res.result.success) {
        const ordersList = res.result.data || []
        
        // 预处理订单列表的显示字段，统一使用 formatAddress 格式化
        const formattedOrders = ordersList.map(order => {
          return {
            ...order,
            displayFrom: formatAddress(order.fromAddress || order.origin || order.startAddress),
            displayTo: formatAddress(order.toAddress || order.destination || order.endAddress),
            displayTime: order.dateTime || order.datetime || order.createTime || '未知',
            statusText: order.statusText || this.getBidStatusText(order.bidStatus) || '未知状态'
          }
        })
        
        wx.hideLoading()
        this.setData({ orders: formattedOrders })
        console.log("🚕我的订单列表：", formattedOrders)
      } else {
        throw new Error(res.result?.message || '获取订单失败')
      }
    } catch (err) {
      wx.hideLoading()
      console.error("❌获取我的订单失败", err)
      wx.showToast({ title: '加载失败', icon: 'none' })
      this.setData({ orders: [] })
    }
  },

  // 查询单个订单状态（用于从报价页面跳转过来）
  async loadOrderStatus() {
    const { orderId } = this.data
    if (!orderId) {
      return
    }

    try {
      wx.showLoading({ title: '加载中...' })
      
      const res = await db.collection('orders_active').doc(orderId).get()
      const order = res.data

      wx.hideLoading()

      if (!order) {
        wx.showToast({ title: '订单不存在', icon: 'none' })
        setTimeout(() => {
          wx.reLaunch({
            url: '/pages/driver/index'
          })
        }, 1500)
        return
      }

      // 预处理单个订单的显示字段
      const displayFrom = formatAddress(order.fromAddress || order.startAddress)
      const displayTo = formatAddress(order.toAddress || order.endAddress)
      const displayTime = order.dateTime || order.createTime || '未知'
      
      this.setData({
        order: order,
        displayFrom,
        displayTo,
        displayTime
      })

      const status = order.status

      // 根据订单状态判断跳转
      if (status === 'accepted') {
        // 司机被选中后自动进入订单详情页
        wx.navigateTo({
          url: '/pages/driver/orderDetail/index?orderId=' + orderId
        })
      } else if (status === 'bidPending') {
        // 等待乘客中，禁止跳转
        console.log('订单状态：等待乘客选择，停留在当前页面')
      } else if (status === 'cancelled') {
        // 接单失败，回抢单页
        wx.reLaunch({
          url: '/pages/driver/index'
        })
      } else {
        // 其他状态（going, finished等），显示订单详情或相应页面
        console.log('订单状态：', status, '，停留在当前页面')
      }
    } catch (err) {
      wx.hideLoading()
      console.error('加载订单状态失败:', err)
      wx.showToast({ title: '加载失败', icon: 'none' })
      setTimeout(() => {
        wx.reLaunch({
          url: '/pages/driver/index'
        })
      }, 1500)
    }
  },

  // 跳转到订单详情页
  goToDetail(e) {
    const { id, index } = e.currentTarget.dataset
    let orderId = id
    
    // 如果从订单列表点击，尝试从 orders 数组中获取
    if (!orderId && index !== undefined && this.data.orders && this.data.orders[index]) {
      const item = this.data.orders[index]
      orderId = item._id || item.order?._id
    }
    
    // 最后兜底
    if (!orderId) {
      orderId = this.data.order?._id || this.data.orderId
    }
    
    if (!orderId) {
      wx.showToast({ title: '订单ID缺失', icon: 'none' })
      return
    }
    console.log("跳转订单 id：", orderId)
    wx.navigateTo({
      url: `/pages/driver/orderDetail/index?orderId=${orderId}`
    })
  },

  startPolling() {
    this.stopPolling()
    this.pollingTimer = setInterval(() => {
      this.refreshOrder()
    }, 3000)
  },

  stopPolling() {
    if (this.pollingTimer) {
      clearInterval(this.pollingTimer)
      this.pollingTimer = null
    }
  },

  refreshOrder() {
    const { orderId } = this.data
    if (!orderId) return

    db.collection('orders_active').doc(orderId).get()
      .then(res => {
        const order = res.data
        if (!order) return

        // 预处理订单显示字段
        const displayFrom = formatAddress(order.origin || order.fromAddress || order.startAddress)
        const displayTo = formatAddress(order.destination || order.toAddress || order.endAddress)
        const displayTime = order.dateTime || order.createTime || '未知'
        
        this.setData({
          order: order,
          displayFrom,
          displayTo,
          displayTime
        })

        const status = order.status
        if (status === 'accepted') {
          this.stopPolling()
          // 跳转到订单详情页，显示接单后的操作按钮
          wx.navigateTo({
            url: `/pages/driver/orderDetail/index?orderId=${orderId}`
          })
        }
      })
      .catch(err => console.error('Poll error:', err))
  },

  // 获取报价状态文本
  getBidStatusText(bidStatus) {
    const statusMap = {
      pending: '等待乘客选择',
      selected: '乘客已选择，待确认接单',
      accepted: '已接单',
      completed: '已完成',
      failed: '报价失败'
    };
    return statusMap[bidStatus] || bidStatus || '未知状态';
  }
})

