const db = wx.cloud.database()
const { formatAddress } = require('../../../utils/orderFormatter.js')

Page({
  data: {
    orders: []
  },

  onShow() {
    this.loadOrders() // 自动更新，确保过期订单不显示
  },

  // 跳转到订单详情页
  goToDetail(e) {
    const orderId = e.currentTarget.dataset.id || e.currentTarget.dataset.order?._id
    if (!orderId) {
      wx.showToast({ title: '订单ID缺失', icon: 'none' })
      return
    }
    console.log("跳转订单 id：", orderId)
    wx.navigateTo({
      url: `/pages/driver/orderDetail/index?orderId=${orderId}`
    })
  },

  loadOrders() {
    wx.showLoading({ title: '加载中...' })

    // 调用云函数获取抢单大厅订单列表
    wx.cloud.callFunction({
      name: 'getOrders',
      data: {
        scene: 'driverHall' // 标识为司机抢单大厅
      }
    }).then(res => {
      console.log('📝 driver/orders - getOrders 返回:', res);
      
      if (res.result && res.result.success) {
        const orders = res.result.data || [];
        
        // 处理订单数据，计算推荐报价
        const pricePerKm = wx.getStorageSync('driverUnitPrice') || wx.getStorageSync('unitPrice') || 2; // 默认 2 元/公里
        const processedOrders = orders.map(order => {
          // 自动报价兜底：默认3公里
          const distance = order.routeInfo?.distance || order.distanceKm || (order.distance ? order.distance / 1000 : 3);
          const recommendedPrice = parseFloat((distance * pricePerKm).toFixed(1));
          
          // 统一格式化地址显示
          const displayFrom = formatAddress(order.fromAddress || order.origin || order.start);
          const displayTo = formatAddress(order.toAddress || order.destination || order.end);
          
          return {
            ...order,
            displayFrom,
            displayTo,
            displayDistance: distance > 0 ? `${distance.toFixed(1)} 公里` : '计算中',
            recommendedPrice: recommendedPrice > 0 ? `¥${recommendedPrice}` : '计算中'
          };
        });
        
        wx.hideLoading();
        this.setData({ orders: processedOrders });
      } else {
        throw new Error(res.result?.message || '获取订单失败');
      }
    }).catch(err => {
      wx.hideLoading();
      console.error("❌获取司机订单失败", err);
      wx.showToast({ title: '加载失败', icon: 'none' });
    });
    
    // 备用方案：直接查询数据库（如果云函数不可用）
    /*
    const now = Date.now();
    const _ = db.command;
    
    db.collection('orders_active')
      .where({
        status: _.in(["pending", "bidPending"]),
        driverLocked: false,
        createTime: _.gte(new Date(now - 30 * 60 * 1000)) // 只显示30分钟内的订单
      })
      .orderBy("createTime", "desc")
      .get()
      .then(res => {
        console.log("🚕司机待抢单列表（备用方案）：", res.data);
        
        // 处理订单数据，计算推荐报价
        const pricePerKm = wx.getStorageSync('driverUnitPrice') || wx.getStorageSync('unitPrice') || 2; // 默认 2 元/公里
        const processedOrders = res.data.map(order => {
          // 自动报价兜底：默认3公里
          const distance = order.routeInfo?.distance || order.distanceKm || (order.distance ? order.distance / 1000 : 3);
          const recommendedPrice = parseFloat((distance * pricePerKm).toFixed(1));
          
          // 统一格式化地址显示
          const displayFrom = formatAddress(order.fromAddress || order.origin || order.start);
          const displayTo = formatAddress(order.toAddress || order.destination || order.end);
          
          return {
            ...order,
            displayFrom,
            displayTo,
            displayDistance: distance > 0 ? `${distance.toFixed(1)} 公里` : '计算中',
            recommendedPrice: recommendedPrice > 0 ? `¥${recommendedPrice}` : '计算中'
          };
        });
        
        wx.hideLoading();
        this.setData({ orders: processedOrders });
      })
      .catch(err => {
        wx.hideLoading();
        console.error("❌获取司机订单失败", err);
      });
    */
  }
})