import { getLocation } from '../../../utils/location'

Page({
  data: { orderId: '' },

  onLoad(e) {
    this.setData({ orderId: e.orderId })
    this.startLocationPush()
  },

  onUnload() {
    if (this.timer) clearInterval(this.timer)
  },

  startLocationPush() {
    this.timer = setInterval(async () => {
      const loc = await getLocation()
      wx.cloud.callFunction({
        name: 'order_flow',
        data: {
          action: 'updateLocation',
          data: {
            orderId: this.data.orderId,
            location: loc
          }
        }
      })
    }, 3000)
  },

  afterBoarding() {
    wx.navigateTo({
      url: `/pages/driver/drive/index?orderId=${this.data.orderId}`
    })
  }
})

