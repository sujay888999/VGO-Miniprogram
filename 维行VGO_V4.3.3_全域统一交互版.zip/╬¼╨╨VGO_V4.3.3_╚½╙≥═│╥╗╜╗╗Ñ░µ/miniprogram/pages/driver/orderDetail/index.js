const app = getApp();
const db = wx.cloud.database();
const { formatAddress, formatDate, formatDistance, formatDuration, formatStatus, normalizeStatus } = require('../../../utils/orderFormatter.js');

Page({
  data: {
    order: null,
    orderId: '',
    statusText: '',
    displayFromAddress: '',
    displayToAddress: '',
    displayDistance: '',
    displayDuration: '',
    autoPrice: '', // 自动报价（字符串展示用）
    manualPrice: '', // 手动输入报价
    useAutoPrice: true, // 默认勾选自动报价
    recommendedPrice: null, // 推荐报价
    statusLabel: '',
    statusClass: '',
    bids: [],
    routeInfo: null,
    distance: 0,
    duration: 0,
    distanceKm: 0,
    durationMin: 0,
    hasRoute: false,
    // UI 状态控制
    showBidButton: false,
    showWaitingBidTip: false,
    showContactPassenger: false,
    showGoPickup: false,
    showFinishTrip: false
  },

  // 格式化司机端订单显示
  formatOrderForView(order) {
    if (!order) return

    // 优先使用 fromAddress.name / toAddress.name，统一使用 formatAddress 格式化
    const displayFromAddress = formatAddress(
      order.fromAddress || order.origin || order.startLocation || order.start
    )

    const displayToAddress = formatAddress(
      order.toAddress || order.destination || order.endLocation || order.end
    )

    const displayDistance = formatDistance(order.distance || order.distanceKm) || '未知距离'
    const displayDuration = formatDuration(order.duration || order.durationMin) || '未知时长'

    // 使用统一的状态格式化函数
    const normalizedStatus = normalizeStatus(order.status);
    const statusText = formatStatus(normalizedStatus);
    
    // 更新订单状态为标准状态
    order.status = normalizedStatus;

    // UI 状态控制
    const status = normalizedStatus;
    
    // 计算推荐报价（优先使用订单的 autoPrice，否则计算）
    const distanceKm = order.distanceKm || order.routeInfo?.distance || (order.distance ? order.distance / 1000 : 3);
    const pricePerKm = wx.getStorageSync('driverUnitPrice') || wx.getStorageSync('unitPrice') || 2; // 默认 2 元/公里
    const recommendedPrice = order.autoPrice || parseFloat((distanceKm * pricePerKm).toFixed(2));
    
    // autoPrice 处理：如果订单有 autoPrice 则使用，否则使用推荐报价
    const autoPrice = order.autoPrice || recommendedPrice || 0;
    
    this.setData({
      order,
      statusText,
      displayFromAddress,
      displayToAddress,
      displayDistance,
      displayDuration,
      autoPrice: autoPrice > 0 ? autoPrice.toFixed(2) : '', // 转换为字符串显示
      recommendedPrice: recommendedPrice > 0 ? recommendedPrice.toFixed(2) : null,
      distanceKm,
      // 报价按钮显示逻辑：waitingDriverBid 和 bidding 才显示
      showBidButton: status === 'waitingDriverBid' || status === 'bidding' || status === 'waiting' || status === 'pending' || status === 'bidPending',
      showWaitingBidTip: status === 'bidding' || status === 'bidPending',
      showContactPassenger: status === 'accepted' || status === 'picking' || status === 'onboard' || status === 'tripStarted' || status === 'going',
      showGoPickup: status === 'accepted',
      showFinishTrip: status === 'tripStarted' || status === 'going',
    })
  },

  onLoad(options) {
    const { orderId } = options
    if (!orderId) {
      wx.showToast({ title: '订单信息缺失', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 800)
      return
    }
    this.setData({ orderId, id: orderId })
    this.loadOrder(orderId)
    
    // 轮询订单状态
    if (!this.polling) {
      this.polling = setInterval(() => {
        this.loadOrder(this.data.orderId, true) // 静默刷新
      }, 3000)
    }
  },

  onUnload() {
    this.stopPollingStatus()
    // 清除轮询
    if (this.polling) {
      clearInterval(this.polling)
      this.polling = null
      }
  },

  loadOrder(orderId, isSilent = false) {
    if (!orderId) {
      orderId = this.data.orderId
    }
      if (!orderId) {
      if (!isSilent) {
        wx.showToast({ title: '订单ID缺失', icon: 'none' })
      }
      return
    }

    if (!isSilent) {
      wx.showLoading({ title: '加载中...' })
    }

    // 根据 orderId 去数据库查询订单数据
    db.collection('orders_active').doc(orderId).get()
      .then(res => {
        if (!isSilent) {
          wx.hideLoading()
        }
        const order = res.data
        if (!order) {
          if (!isSilent) {
            wx.showToast({ title: '订单不存在', icon: 'none' })
            setTimeout(() => wx.navigateBack(), 1500)
          }
          return
        }
        
        // 增强容错：设置订单数据，防止 undefined 报错
        // 确保 autoPrice 有值（如果订单没有，则计算）
        const distanceKm = order.distanceKm || order.routeInfo?.distance || (order.distance ? order.distance / 1000 : 3);
        const pricePerKm = order.pricePerKm || wx.getStorageSync('driverUnitPrice') || wx.getStorageSync('unitPrice') || 2;
        const calculatedAutoPrice = order.autoPrice || parseFloat((distanceKm * pricePerKm).toFixed(2));
        
        this.setData({
          order: {
            ...order,
            // 防止 undefined 报错
            distance: order.distance || 0,
            duration: order.duration || 0,
            distanceKm: distanceKm,
            autoPrice: calculatedAutoPrice, // 确保 autoPrice 有值
            pricePerKm: pricePerKm,
            // 默认状态 waitingDriverBid
            status: order.status || 'waitingDriverBid',
          }
        })
        
        // 使用统一格式化函数
        this.formatOrderForView(order)
        this.processOrderData(order)
        
        // 启动自动轮询订单状态（仅在等待乘客选择时轮询）
        const normalizedStatus = normalizeStatus(order.status);
        if (normalizedStatus === 'bidding' || order.status === 'bidPending' || order.status === 'waitingBid') {
          this.startPollingStatus(orderId)
    }
      })
      .catch(err => {
        if (!isSilent) {
          wx.hideLoading()
          wx.showToast({ title: '加载失败', icon: 'none' })
        }
        console.error("loadOrder error:", err)
      })
  },

  async loadOrderOld() {
    // 如果已有订单数据，直接使用
    if (this.data.order && this.data.order._id === this.data.orderId) {
      this.processOrderData(this.data.order);
      return;
    }
    
    wx.showLoading({ title: '加载中...' });
    try {
      const res = await db.collection('orders_active').doc(this.data.orderId).get();
      const order = res.data;

      const statusMap = {
        pending: '待匹配',
        bidPending: '等待乘客选择',
        accepted: '已接单',
        confirmed: '已确认',
        going: '进行中',
        completed: '已完成',
        cancelled: '已取消',
      };

      const statusClassMap = {
        pending: 'tag-wait',
        bidPending: 'tag-bidding',
        accepted: 'tag-matched',
        confirmed: 'tag-matched',
        going: 'tag-going',
        completed: 'tag-finished',
        cancelled: 'tag-cancelled'
      };

      this.processOrderData(order);
    } catch (err) {
      console.error('loadOrder error:', err);
      wx.showToast({ title: '订单加载失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  // 处理订单数据
  async processOrderData(order) {
    // 确保 order 对象有 _id
    if (order && !order._id) {
      order._id = this.data.orderId;
    }

      // 使用统一的状态映射（方案 A）（使用文件顶部已引入的函数）
      const normalizedStatus = normalizeStatus(order.status);

    const statusMap = {
        waitingDriverBid: '等待司机抢单',
        bidding: '司机报价中',
        passengerSelect: '等待乘客选择司机',
        accepted: '司机已接单，待接乘客',
        picking: '司机前往上车点',
        onboard: '乘客已上车',
        tripStarted: '行程进行中',
        completed: '已完成',
        cancelled: '已取消',
    };

    const statusClassMap = {
        waitingDriverBid: 'tag-wait',
      bidding: 'tag-bidding',
        passengerSelect: 'tag-bidding',
        accepted: 'tag-matched',
        picking: 'tag-going',
        onboard: 'tag-going',
        tripStarted: 'tag-going',
        completed: 'tag-finished',
        cancelled: 'tag-cancelled'
    };
      
      // 更新订单状态为标准状态
      order.status = normalizedStatus;

    this.setData({
      order: order, // order 已经在 loadOrder 中格式化过了
      bids: Array.isArray(order.bids) ? order.bids : [],
      statusLabel: statusMap[normalizedStatus] || formatStatus(normalizedStatus) || '未知状态',
      statusClass: statusClassMap[normalizedStatus] || 'tag-wait'
    });

    // 如果订单中已有 distance 和 duration，直接使用；否则调用路线计算
    if (order.distance && order.duration) {
      this.setData({
        distanceKm: order.distance,
        durationMin: order.duration,
        distance: order.distance,
        duration: order.duration
      });
    } else {
      // 订单信息加载完成后，调用路线计算
      this.fetchRoute(order);
    }
  },


  // 确认接单
  async acceptOrder() {
    const { orderId } = this.data;
    const order = this.data.order;

    if (!orderId || !order) {
      wx.showToast({ title: '订单信息缺失', icon: 'none' });
      return;
    }

    wx.showLoading({ title: '处理中...' });

    try {
      const res = await wx.cloud.callFunction({
        name: 'acceptBid',
        data: {
          orderId,
          bidId: order.bidId || ''
        }
      });

      wx.hideLoading();

      if (res.result && res.result.success) {
        wx.showToast({ title: '接单成功', icon: 'success' });
        setTimeout(() => {
          this.loadOrder();
        }, 1000);
      } else {
        wx.showToast({ 
          title: res.result?.message || '接单失败', 
          icon: 'none' 
        });
      }
    } catch (err) {
      wx.hideLoading();
      console.error('acceptOrder error:', err);
      wx.showToast({ title: '服务器错误', icon: 'none' });
    }
  },


  fetchRoute(order) {
    if (!order || !order.fromLocation || !order.toLocation) {
      console.warn('订单缺少起终点坐标，无法计算路线', order);
      this.setData({ hasRoute: false, distanceKm: 0, durationMin: 0 });
      return;
    }

    const from = `${order.fromLocation.lng},${order.fromLocation.lat}`;
    const to = `${order.toLocation.lng},${order.toLocation.lat}`;

    console.log('调用 getRoute，本地计算路线:', { from, to });

    wx.showLoading({ title: '获取路线中...', mask: true });

    wx.cloud.callFunction({
      name: 'getRoute',
      data: { from, to },
    })
      .then(res => {
        console.log('getRoute result (driver):', res);
        const result = res.result || {};
        if (result.success && result.data) {
          const { distance, duration } = result.data;
          // 格式化距离和时间
          const displayDistance = formatDistance(distance)
          const displayDuration = formatDuration(duration)
          
          this.setData({
            distanceKm: distance,
            durationMin: duration,
            hasRoute: true,
            distance: distance,
            duration: duration,
            'order.distance': distance,
            'order.duration': duration,
            displayDistance,
            displayDuration
          });
        } else {
          console.warn('路线规划失败或返回空数据:', result);
          this.setData({
            hasRoute: false,
            distanceKm: 0,
            durationMin: 0,
            distance: 0,
            duration: 0,
            displayDistance: '',
            displayDuration: ''
          });
        }
      })
      .catch(err => {
        console.error('getRoute fail (driver):', err);
        this.setData({
          hasRoute: false,
          distanceKm: 0,
          durationMin: 0,
          distance: 0,
          duration: 0,
        });
      })
      .finally(() => {
        wx.hideLoading();
      });
  },

  // 自动轮询订单状态
  startPollingStatus(orderId) {
    this.stopPollingStatus()
    if (!orderId) {
      orderId = this.data.orderId
    }
    if (!orderId) return

    this.pollingTimer = setInterval(() => {
      db.collection('orders_active').doc(orderId).get()
        .then(res => {
          const order = res.data
          if (!order) return

          const status = order.status
          // 兼容新状态和旧状态
          if (status === 'accepted') {
            this.stopPollingStatus()
            // 重新加载订单详情，显示接单后的操作按钮
            this.loadOrder(orderId)
          } else {
            // 更新订单数据并重新格式化
            this.formatOrderForView(order)
          }
        })
        .catch(err => {
          console.error('轮询订单状态失败:', err)
        })
    }, 3000)
  },

  stopPollingStatus() {
    if (this.pollingTimer) {
      clearInterval(this.pollingTimer)
      this.pollingTimer = null
    }
  },

  // 修复价格输入，支持小数（替换原数字校验）
  onPriceInput(e) {
    let val = e.detail.value;
    // 只允许数字和一个小数点，最多两位小数
    val = val.replace(/[^\d.]/g, "").replace(/^\./, "");
    // 限制最多两位小数
    const parts = val.split('.');
    if (parts.length > 1 && parts[1].length > 2) {
      val = parts[0] + '.' + parts[1].substring(0, 2);
    }
    this.setData({ manualPrice: val });
  },

  // PATCH: 手动报价输入处理（替换原数字校验）
  onManualBidInput(e) {
    const value = e.detail.value
    const valid = value.replace(/[^\d.]/g, "").replace(/^\./, "");
    this.setData({ manualBidPrice: valid })
  },

  // PATCH: 提交手动报价
  submitManualBid() {
    const price = parseFloat(this.data.manualBidPrice)
    if (isNaN(price) || price <= 0) {
      wx.showToast({
        title: '请输入正确的报价金额',
        icon: 'none'
      })
      return
    }

    const order = this.data.order
    const driverOpenId = app.globalData.openid || wx.getStorageSync('openid')
    const driverPhone = app.globalData.phone || wx.getStorageSync('phone')

    if (!driverOpenId || !driverPhone) {
      wx.showToast({ title: '登录信息缺失', icon: 'none' })
      return
    }

    // 获取订单距离和单价
    const distanceKm = order.distanceKm || order.routeInfo?.distance || (order.distance ? order.distance / 1000 : 3);
    const unitPrice = wx.getStorageSync('driverUnitPrice') || wx.getStorageSync('unitPrice') || 2;
    const durationMin = order.durationMin || order.routeInfo?.duration || 0;

    const payload = {
      orderId: order._id,
      driverOpenId: driverOpenId,
      driverPhone: driverPhone,
      price: price, // 手动报价金额
      unitPrice: unitPrice, // 每公里单价
      distanceKm: distanceKm, // 订单预估里程
      durationMin: durationMin // 订单预估时间
    }

    wx.showLoading({ title: '提交中…', mask: true })

    wx.cloud.callFunction({
      name: 'createBid',
      data: payload
    }).then(res => {
      const result = res.result || {}
      console.log('createBid 返回:', result)
      if (!result.success) {
        wx.showToast({
          title: result.message || '报价失败',
          icon: 'none'
        })
        return
      }

      // createBid 已经更新状态为 bidPending，不需要再次调用
      return Promise.resolve({ result: { success: true } })
    }).then(updateRes => {
      if (updateRes && updateRes.result && updateRes.result.success) {
        wx.showToast({
          title: '报价成功，等待乘客选择',
          icon: 'none'
        })
        this.setData({
          showBidDialog: false,
          manualBidPrice: ''
        })
        setTimeout(() => {
          wx.redirectTo({
            url: '/pages/driver/myOrder/index'
          })
        }, 800)
      }
    }).catch(err => {
      console.error('手动报价失败:', err)
      wx.showToast({ title: '服务器错误', icon: 'none' })
    }).finally(() => {
      wx.hideLoading()
    })
  },

  // 提交报价（立即抢单）
  submitBid() {
    const { bidPrice, order } = this.data
    const app = getApp()
    
    if (!order || !order._id) {
      wx.showToast({ title: '订单信息缺失', icon: 'none' })
      return
    }

    const driverOpenId = app.globalData.openid || wx.getStorageSync('openid')
    const driverPhone = app.globalData.phone || wx.getStorageSync('phone')

    if (!driverOpenId) {
      wx.showToast({ title: '登录信息缺失，请重新登录', icon: 'none' })
      return
    }

    if (!driverPhone) {
      wx.showToast({ title: '司机电话缺失，请完善个人信息', icon: 'none' })
      return
    }

    // 自动报价兜底：默认3公里
    const distanceKm = order.distanceKm || order.routeInfo?.distance || (order.distance ? order.distance / 1000 : 3);
    const durationMin = order.durationMin || order.routeInfo?.duration || order.duration || 0;
    const pricePerKm = wx.getStorageSync('driverUnitPrice') || wx.getStorageSync('unitPrice') || 2;

    // 如果用户输入了价格，使用手动价格；否则使用订单的 autoPrice 或自动计算
    let finalBidPrice = null
    if (bidPrice && Number(bidPrice) > 0) {
      finalBidPrice = Number(bidPrice)
    } else {
      // 优先使用订单的 autoPrice，否则自动计算
      finalBidPrice = order.autoPrice || parseFloat((distanceKm * pricePerKm).toFixed(2));
    }

    console.log("提交报价:", { bidPrice, finalBidPrice, distanceKm, pricePerKm })

    wx.showLoading({ title: '抢单中...' })

    wx.cloud.callFunction({
      name: 'createBid',
        data: {
        orderId: order._id,
        driverOpenId: driverOpenId,
        driverPhone: driverPhone,
        price: finalBidPrice, // 手动报价金额
        unitPrice: pricePerKm, // 每公里单价
        distanceKm: distanceKm, // 订单预估里程（公里）
        durationMin: durationMin // 订单预估时间（分钟）
        }
    }).then(res => {
      console.log("createBid 返回:", res)
      if (res.result && res.result.success) {
        // createBid 已经更新状态为 bidPending，不需要再次调用
        return Promise.resolve({ result: { success: true } })
      } else {
        throw new Error(res.result?.message || '报价失败')
      }
    }).then(() => {
      wx.hideLoading()
      // PATCH: 报价成功后跳转到我的订单，显示等待乘客选择状态
      wx.showToast({
        title: '报价成功，等待乘客选择',
        icon: 'none'
      })
      setTimeout(() => {
        wx.redirectTo({
          url: '/pages/driver/myOrder/index'
        })
      }, 800)
    }).catch(err => {
      console.error("submitBid error:", err)
      wx.hideLoading()
      wx.showToast({ title: err.message || '报价失败', icon: 'none' })
    })
  },

  // 联系乘客
  onCallPassenger() {
    const { order } = this.data
    if (!order || !order.passengerPhone) {
      wx.showToast({ title: '暂无乘客电话', icon: 'none' })
      return
    }
    wx.makePhoneCall({
      phoneNumber: order.passengerPhone,
    })
  },

  // 旧的联系乘客方法（保留兼容）
  callPassenger() {
    this.onCallPassenger()
  },

  // 已到达上车点（合并到开始行程，直接开始行程）
  onArrivePickup() {
    // 直接调用开始行程
    this.onStartTrip()
  },

  // 开始行程
  onStartTrip() {
    const { order } = this.data
    if (!order || !order._id) return

    wx.showLoading({ title: '更新中...' })
    wx.cloud
      .callFunction({
        name: 'updateOrderStatus',
        data: {
          orderId: order._id,
          status: 'tripStarted',
        },
      })
      .then((resp) => {
        const result = resp.result || {}
        if (result.success) {
          wx.showToast({ title: '已开始行程', icon: 'success' })
          this.formatOrderForView({
            ...order,
            status: 'tripStarted',
          })
        } else {
          wx.showToast({
            title: result.message || '操作失败',
            icon: 'none',
          })
      }
      })
      .catch((err) => {
        console.error('onStartTrip error:', err)
        wx.showToast({ title: '服务器错误', icon: 'none' })
      })
      .finally(() => {
        wx.hideLoading()
      })
  },

  // 结束行程
  onFinishTrip() {
    const { order } = this.data
    if (!order || !order._id) return

    wx.showLoading({ title: '结束中...' })
    wx.cloud
      .callFunction({
        name: 'updateOrderStatus',
        data: {
          orderId: order._id,
          status: 'completed',
        },
      })
      .then((resp) => {
        const result = resp.result || {}
        if (result.success) {
          wx.showToast({ title: '行程已完成', icon: 'success' })
          this.formatOrderForView({
            ...order,
            status: 'completed',
          })
        } else {
          wx.showToast({
            title: result.message || '操作失败',
            icon: 'none',
          })
        }
      })
      .catch((err) => {
        console.error('onFinishTrip error:', err)
        wx.showToast({ title: '服务器错误', icon: 'none' })
      })
      .finally(() => {
        wx.hideLoading()
      })
  },

  // PATCH: 关闭报价弹窗
  closeBidDialog() {
    this.setData({ showBidDialog: false, manualBidPrice: '' })
  }
});