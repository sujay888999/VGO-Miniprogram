const db = wx.cloud.database()

Page({
  data: { img:'' },

  choosePhoto() {
    wx.chooseImage({
      count:1,
      success: res => this.setData({ img: res.tempFilePaths[0] })
    })
  },

  async submit() {
    if(!this.data.img)
      return wx.showToast({ title:'请上传驾驶证', icon:'none' })

    const name = wx.getStorageSync('driver_name')
    const phone = wx.getStorageSync('phone')

    await db.collection('driver_info').add({
      data:{
        name,
        phone,
        license: this.data.img,
        status:1,
        createdAt: Date.now()
      }
    })

    wx.showToast({ title:'注册成功' })
    wx.navigateBack({ delta:3 })
  }
})

