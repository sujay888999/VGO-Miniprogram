Page({
  goProfile() {
    wx.navigateTo({
      url: '/pages/driver/register/profile/index'
    })
  }
})
