const db = wx.cloud.database();

Page({
  data: { name: '' },

  onNameInput(e) {
    this.setData({ name: e.detail.value });
  },

  async quickRegister() {
    if (!this.data.name) {
      wx.showToast({ title: '请输入姓名', icon: 'none' })
      return;
    }

    const openid = wx.getStorageSync('openid');
    if (!openid) {
      wx.showToast({ title: '请先登录', icon: 'none' })
      return;
    }

    try {
      wx.showLoading({ title: '注册中...' })

      await db.collection('drivers').add({
        data: {
          openid,
          name: this.data.name,
          status: 'approved', // 审核通过
          createdAt: new Date()
        }
      });

      wx.setStorageSync('isDriver', true);

      wx.hideLoading()
      wx.showToast({ title: '注册成功！', icon: 'success' });

      setTimeout(() => {
        wx.reLaunch({
          url: '/pages/driver/index/index'
        })
      }, 800);
    } catch (err) {
      wx.hideLoading()
      console.error('注册失败:', err)
      wx.showToast({ title: '注册失败，请重试', icon: 'none' })
    }
  }
})
