const app = getApp()

Page({
  data: {
    phone: "",
    code: "",
    role: "passenger",
    codeText: "获取验证码",
    counting: false,
    isSubmitting: false
  },

  onLoad(options = {}) {
    const cachedAuth = wx.getStorageSync("auth") || {}
    const role = options.role || cachedAuth.role || "passenger"
    if (!options.role && !cachedAuth.role) {
      console.warn("login: role not provided, defaulting to passenger")
    }
    this.setData({ role })
  },

  onUnload() {
    if (this.codeTimer) {
      clearInterval(this.codeTimer)
      this.codeTimer = null
    }
  },

  onPhoneInput(e) {
    this.setData({ phone: e.detail.value });
  },

  onCodeInput(e) {
    this.setData({ code: e.detail.value });
  },

  onGetCode() {
    if (this.data.counting) return;
    if (!/^1[3-9]\d{9}$/.test(this.data.phone)) {
      wx.showToast({ title: "手机号不正确", icon: "none" });
      return;
    }

    wx.showToast({ title: "验证码：123456", icon: "none" });

    this.setData({ counting: true });

    let sec = 60;
    this.setData({ codeText: sec + "s" });

    this.codeTimer = setInterval(() => {
      sec--;
      if (sec <= 0) {
        clearInterval(this.codeTimer);
        this.codeTimer = null
        this.setData({ counting: false, codeText: "重新获取" });
      } else {
        this.setData({ codeText: sec + "s" });
      }
    }, 1000);
  },

  async onSubmitLogin() {
    if (!/^1[3-9]\d{9}$/.test(this.data.phone)) {
      wx.showToast({ title: "手机号不正确", icon: "none" });
      return;
    }
    if (this.data.code.length < 4) {
      wx.showToast({ title: "验证码错误", icon: "none" });
      return;
    }

    wx.showLoading({ title: "登录中..." });
    this.setData({ isSubmitting: true })

    try {
      const res = await wx.cloud.callFunction({
        name: "login",
        data: {
          phone: this.data.phone,
          role: this.data.role,
          isLogged: true
        }
      });

      wx.hideLoading();

      if (res.result && res.result.success) {
        const user = res.result.data;

        wx.setStorageSync('openid', user.openid)
        wx.setStorageSync('phone', user.phone)

        const auth = {
          openid: user.openid,
          phone: user.phone,
          avatar: user.avatar || "/images/default-avatar.png",
          isLogged: true
        };

        app.saveAuth(auth);

        wx.reLaunch({
          url: "/pages/index/index"
        });
      } else {
        wx.showToast({ title: res.result?.msg || "登录失败", icon: "none" });
      }
    } catch (err) {
      wx.hideLoading();
      wx.showToast({ title: "服务器错误", icon: "none" });
      console.error("login error:", err);
    } finally {
      this.setData({ isSubmitting: false })
    }
  }
});

