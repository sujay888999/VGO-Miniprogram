
import { getPreferences, savePreferences } from '../../../utils/preferences'

Page({
  data: {
    preferences: getPreferences(),
    musicOptions: ['安静', '轻音乐', '动感'],
    musicValues: ['quiet', 'light', 'dynamic'],
    musicIndex: 0,
    fragranceOptions: ['无', '清淡', '木质', '花香'],
    fragranceValues: ['none', 'light', 'woody', 'floral'],
    fragranceIndex: 0,
    motionOptions: ['不易晕车', '一般', '容易晕车'],
    motionValues: ['low', 'mid', 'high'],
    motionIndex: 1,
    seatOptions: ['后排左侧', '后排右侧', '副驾驶'],
    seatValues: ['rear-left', 'rear-right', 'front'],
    seatIndex: 0,
    comfortOptions: ['标准', '舒适', '尊享'],
    comfortValues: ['standard', 'premium', 'lux'],
    comfortIndex: 0
  },

  onShow() {
    const prefs = getPreferences()
    this.setData({
      preferences: prefs,
      musicIndex: this.data.musicValues.indexOf(prefs.music),
      fragranceIndex: this.data.fragranceValues.indexOf(prefs.fragrance),
      motionIndex: this.data.motionValues.indexOf(prefs.motion_sensitivity),
      seatIndex: this.data.seatValues.indexOf(prefs.seat),
      comfortIndex: this.data.comfortValues.indexOf(prefs.comfortLevel)
    })
  },

  get musicLabel() {
    return this.data.musicOptions[this.data.musicIndex] || ''
  },

  onMusicChange(e) {
    const idx = Number(e.detail.value)
    this.setData({
      musicIndex: idx,
      'preferences.music': this.data.musicValues[idx]
    })
  },

  onChatChange(e) {
    this.setData({
      'preferences.chat': e.detail.value
    })
  },

  onFragranceChange(e) {
    const idx = Number(e.detail.value)
    this.setData({
      fragranceIndex: idx,
      'preferences.fragrance': this.data.fragranceValues[idx]
    })
  },

  onWindowChange(e) {
    this.setData({
      'preferences.window': e.detail.value
    })
  },

  onTempMinBlur(e) {
    const val = Number(e.detail.value) || this.data.preferences.temperature[0]
    this.setData({
      'preferences.temperature[0]': val
    })
  },

  onTempMaxBlur(e) {
    const val = Number(e.detail.value) || this.data.preferences.temperature[1]
    this.setData({
      'preferences.temperature[1]': val
    })
  },

  onMotionChange(e) {
    const idx = Number(e.detail.value)
    this.setData({
      motionIndex: idx,
      'preferences.motion_sensitivity': this.data.motionValues[idx]
    })
  },

  onPetChange(e) {
    this.setData({
      'preferences.pet': e.detail.value
    })
  },

  onLuggageChange(e) {
    this.setData({
      'preferences.luggage': e.detail.value
    })
  },

  onSeatChange(e) {
    const idx = Number(e.detail.value)
    this.setData({
      seatIndex: idx,
      'preferences.seat': this.data.seatValues[idx]
    })
  },

  onComfortChange(e) {
    const idx = Number(e.detail.value)
    this.setData({
      comfortIndex: idx,
      'preferences.comfortLevel': this.data.comfortValues[idx]
    })
  },

  onSave() {
    savePreferences(this.data.preferences)
    wx.showToast({
      title: '已保存',
      icon: 'success'
    })
    setTimeout(() => {
      wx.navigateBack()
    }, 600)
  }
})
