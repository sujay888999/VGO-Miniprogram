# 腾讯地图 SDK 下载说明

## ⚠️ 重要提示

官方 URL 当前无法直接下载，请按照以下步骤手动下载：

## 📥 下载步骤

### 方法一：从腾讯地图开放平台下载（推荐）

1. 访问腾讯地图开放平台：https://lbs.qq.com/
2. 登录您的账号
3. 进入控制台
4. 导航到：**组件** → **微信小程序**
5. 下载 `qqmap-wx-jssdk.js` 文件
6. 将下载的文件重命名为 `qqmap-wx-jssdk.js`
7. 放置到：`miniprogram/libs/qqmap-wx-jssdk.js`

### 方法二：从官方示例项目获取

1. 访问腾讯地图官方示例项目
2. 查找 `libs/qqmap-wx-jssdk.js` 文件
3. 复制文件内容
4. 保存到：`miniprogram/libs/qqmap-wx-jssdk.js`

### 方法三：使用 npm（如果支持）

```bash
npm install qqmap-wx-jssdk
```

然后从 `node_modules` 中复制文件到 `miniprogram/libs/`

## ✅ 验证

下载完成后，请确认：
- 文件路径：`miniprogram/libs/qqmap-wx-jssdk.js`
- 文件大小：通常 > 50KB
- `app.js` 中的导入路径已正确：`const QQMapWX = require('./libs/qqmap-wx-jssdk.js');`

## 🔗 相关链接

- 腾讯地图开放平台：https://lbs.qq.com/
- 微信小程序 SDK 文档：https://lbs.qq.com/webApi/component/componentGuide/componentGuide

