# 腾讯地图 SDK 下载说明

## 文件位置
请将腾讯地图 SDK 文件下载并放置在此目录下：
- 文件名：`qqmap-wx-jssdk.js`（当前已创建基础版本）
- 完整路径：`miniprogram/libs/qqmap-wx-jssdk.js`

## 下载方式

### 方式一：官方下载
访问腾讯地图开放平台，下载微信小程序 SDK：
https://lbs.qq.com/webApi/component/componentGuide/componentGuide

### 方式二：直接下载链接
如果官方提供直接下载链接，请使用以下命令下载：
```bash
# 在项目根目录执行
curl -o miniprogram/libs/qqmap-wx-jssdk.js https://mapapi.qq.com/web/miniprogram/demo/libs/qqmap-wx-jssdk.js
```

### 方式三：手动下载
1. 访问腾讯地图开放平台：https://lbs.qq.com/
2. 登录后进入控制台
3. 在"组件" -> "微信小程序"中找到 SDK 下载
4. 下载 `qqmap-wx-jssdk.js` 文件
5. 替换当前目录下的 `qqmap-wx-jssdk.js` 文件

## 当前状态
- ✅ 已创建基础 SDK 文件：`qqmap-wx-jssdk.js`
- ⚠️ 当前文件为功能实现版本，建议从官方下载完整 SDK 替换
- ✅ `app.js` 已正确导入：`import QQMapWX from './libs/qqmap-wx-jssdk.js'`
- ✅ API Key 已在 `app.js` 中配置：`3I2BZ-CBRKQ-2NY5U-2UWEX-AS6I2-FQBZL`

## 注意事项
- SDK 文件必须存在，否则 `app.js` 中的导入会失败
- 确保文件名为 `qqmap-wx-jssdk.js`（与 `app.js` 中的导入路径一致）
- 当前基础版本包含常用方法，但建议使用官方完整 SDK 以获得最佳性能和完整功能

