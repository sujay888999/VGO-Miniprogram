const cloud = require('wx-server-sdk');

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

const db = cloud.database();

const orders = db.collection('orders_active');

exports.main = async (event, context) => {
  // DEBUG 日志：打印入参
  console.log('📝 publishTrip DEBUG - event:', JSON.stringify(event, null, 2));
  
  try {
    const { OPENID } = cloud.getWXContext();

    // 参数重命名映射
    const { 
      passengerOpenId,
      passengerPhone,
      fromAddress, 
      toAddress, 
      fromLocation, 
      toLocation, 
      dateTime,
      remark = "",
      distance = 0,
      duration = 0
    } = event;

    if (!passengerOpenId || !fromAddress || !toAddress || !fromLocation || !toLocation || !dateTime) {
      return { 
        success: false, 
        code: 400, 
        message: "缺少参数：起点、终点、时间或用户身份"
      };
    }

    // 调用 getRoute 获取路线信息
    let routeInfo = { distance: 0, duration: 0 };
    try {
      const fromStr = `${fromLocation.lng || fromLocation.longitude},${fromLocation.lat || fromLocation.latitude}`;
      const toStr = `${toLocation.lng || toLocation.longitude},${toLocation.lat || toLocation.latitude}`;
      
      const routeRes = await cloud.callFunction({
        name: 'getRoute',
        data: { from: fromStr, to: toStr }
      });
      
      if (routeRes.result && routeRes.result.success && routeRes.result.data) {
        routeInfo = {
          distance: routeRes.result.data.distance || 0, // 公里
          duration: routeRes.result.data.duration || 0 // 分钟
        };
        console.log('✅ publishTrip 路线规划成功:', routeInfo);
      }
    } catch (routeErr) {
      console.error('⚠️ publishTrip 路线规划失败，使用默认值:', routeErr);
    }

    // 统一入库字段格式（优先使用路线规划结果，无路线规划时自动报价兜底：默认3公里）
    const distanceKm = parseFloat(event.distanceKm || routeInfo.distance || distance || 3);
    const durationMin = parseInt(event.durationMin || routeInfo.duration || duration || 0);

    // 格式化地址对象（保留对象结构，包含 name 字段）
    const formatAddressObj = (address, location) => {
      if (typeof address === 'object' && address !== null) {
        return { 
          name: address.name || address.address || "",
          address: address.address || address.name || "",
          latitude: location?.lat || location?.latitude || 0,
          longitude: location?.lng || location?.longitude || 0
        };
      } else {
        return { 
          name: address || "",
          address: address || "",
          latitude: location?.lat || location?.latitude || 0,
          longitude: location?.lng || location?.longitude || 0
        };
      }
    };

    // 格式化地址：确保 fromAddress / toAddress 包含 name 字段
    const formatAddressWithName = (address) => {
      if (typeof address === 'string') {
        return { name: address, address: address };
      }
      if (typeof address === 'object' && address !== null) {
        return {
          name: address.name || address.address || '',
          address: address.address || address.name || ''
        };
      }
      return { name: '', address: '' };
    };

    // 计算 autoPrice（默认单价 2 元/公里）
    const defaultUnitPrice = 2;
    const autoPrice = parseFloat((distanceKm * defaultUnitPrice).toFixed(2));

    const fromAddressObj = formatAddressWithName(fromAddress);
    const toAddressObj = formatAddressWithName(toAddress);

    const data = {
      passengerOpenId: passengerOpenId || OPENID,
      passengerPhone: passengerPhone || '',
      fromAddress: fromAddressObj, // 对象，包含 name 和 address
      toAddress: toAddressObj, // 对象，包含 name 和 address
      fromLocation: fromLocation || {}, // 对象，包含 lat, lng
      toLocation: toLocation || {}, // 对象，包含 lat, lng
      startLocation: fromLocation,
      endLocation: toLocation,
      dateTime: dateTime || new Date(),
      remark: remark || '',
      distance: distanceKm,
      duration: durationMin,
      routeInfo: {
        distance: distanceKm, // 公里
        duration: durationMin // 分钟
      },
      status: "waiting", // 统一为 "waiting"（等待司机抢单）
      distanceKm: distanceKm, // 确保写入数据库不缺失
      durationMin: durationMin, // 确保写入数据库不缺失
      driverOpenId: "", // 已选中的司机 openid（未选司机则为空）
      driverPhone: "", // 司机手机号
      driverLocked: false, // 是否锁定给某个司机
      bids: [], // 存放所有报价记录
      selectedBidId: "", // 乘客最终选中的报价 id
      autoPrice: autoPrice, // 自动计算的报价（距离 * 单价）
      expireTime: Date.now() + 30 * 60 * 1000, // 30 分钟有效期
      createTime: new Date(),
      updateTime: new Date(),
      // TODO: 预留扩展字段
      passengerRate: null, // 乘客对司机的评分
      driverRate: null, // 司机对乘客的评分
      payAmount: null // 实际支付金额
    };

    const result = await orders.add({ data });

    // DEBUG 日志：打印插入结果
    console.log('✅ publishTrip 新订单插入成功 - _id:', result._id);
    console.log('✅ publishTrip 订单数据:', JSON.stringify(data, null, 2));

    return {
      success: true,
      code: 200,
      message: "订单创建成功",
      data: { 
        orderId: result._id,
        status: data.status
      }
    };
  } catch (err) {
    console.error('🔥 publishTrip ERROR:', err);
    return {
      success: false,
      code: 500,
      message: '服务器错误',
      error: err.toString(),
    };
  }
};
