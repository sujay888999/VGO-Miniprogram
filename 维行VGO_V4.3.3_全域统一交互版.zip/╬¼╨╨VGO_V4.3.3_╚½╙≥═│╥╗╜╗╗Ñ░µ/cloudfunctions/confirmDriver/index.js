const cloud = require('wx-server-sdk')
cloud.init()
const db = cloud.database()

exports.main = async (event, context) => {
  const { orderId, bidId, driverOpenId } = event

  // 参数校验
  if (!orderId || !bidId || !driverOpenId) {
    return {
      success: false,
      code: 400,
      message: '参数缺失（orderId / bidId / driverOpenId 必填）'
    }
  }

  try {
    // 读取订单
    const orderRes = await db.collection('orders_active').doc(orderId).get()
    const order = orderRes.data

    if (!order) {
      return { success: false, code: 404, message: '订单不存在' }
    }

    // 找到该司机的报价信息
    const targetBid = (order.bids || []).find(b => b._id === bidId)
    if (!targetBid) {
      return { success: false, code: 404, message: '该司机报价不存在' }
    }

    // 将订单状态更新为已选司机
    await db.collection('orders_active').doc(orderId).update({
      data: {
        status: 'driver_selected',
        selectedDriver: {
          driverOpenId,
          price: targetBid.price,
          driverPhone: targetBid.driverPhone || '',
          bidId
        }
      }
    })

    return {
      success: true,
      code: 200,
      message: '司机选择成功'
    }

  } catch (err) {
    console.error('confirmDriver error:', err)
    return {
      success: false,
      code: 500,
      message: '服务器错误，请稍后再试'
    }
  }
}
