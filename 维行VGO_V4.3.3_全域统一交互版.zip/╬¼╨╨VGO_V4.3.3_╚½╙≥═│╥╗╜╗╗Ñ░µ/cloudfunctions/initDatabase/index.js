const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()

/**
 * 数据库初始化云函数
 * 创建核心集合和索引结构
 */
exports.main = async (event, context) => {
  console.log('[initDatabase] 开始初始化数据库结构...')

  try {
    const results = {
      collections: [],
      indexes: [],
      errors: []
    }

    // 1. 创建 users 集合（如果不存在）
    try {
      await db.createCollection('users')
      results.collections.push('users')
      console.log('✅ 创建集合: users')
    } catch (err) {
      if (err.errCode !== -1) { // -1 表示集合已存在
        results.errors.push({ collection: 'users', error: err.message })
      } else {
        results.collections.push('users (已存在)')
      }
    }

    // 2. 创建 passenger_profiles 集合
    try {
      await db.createCollection('passenger_profiles')
      results.collections.push('passenger_profiles')
      console.log('✅ 创建集合: passenger_profiles')
    } catch (err) {
      if (err.errCode !== -1) {
        results.errors.push({ collection: 'passenger_profiles', error: err.message })
      } else {
        results.collections.push('passenger_profiles (已存在)')
      }
    }

    // 3. 创建 driver_profiles 集合
    try {
      await db.createCollection('driver_profiles')
      results.collections.push('driver_profiles')
      console.log('✅ 创建集合: driver_profiles')
    } catch (err) {
      if (err.errCode !== -1) {
        results.errors.push({ collection: 'driver_profiles', error: err.message })
      } else {
        results.collections.push('driver_profiles (已存在)')
      }
    }

    // 4. 创建 vehicles 集合
    try {
      await db.createCollection('vehicles')
      results.collections.push('vehicles')
      console.log('✅ 创建集合: vehicles')
    } catch (err) {
      if (err.errCode !== -1) {
        results.errors.push({ collection: 'vehicles', error: err.message })
      } else {
        results.collections.push('vehicles (已存在)')
      }
    }

    // 5. 创建 driver_settings 集合
    try {
      await db.createCollection('driver_settings')
      results.collections.push('driver_settings')
      console.log('✅ 创建集合: driver_settings')
    } catch (err) {
      if (err.errCode !== -1) {
        results.errors.push({ collection: 'driver_settings', error: err.message })
      } else {
        results.collections.push('driver_settings (已存在)')
      }
    }

    // 6. 创建 orders_active 集合并创建索引
    try {
      await db.createCollection('orders_active')
      results.collections.push('orders_active')
      console.log('✅ 创建集合: orders_active')
    } catch (err) {
      if (err.errCode !== -1) {
        results.errors.push({ collection: 'orders_active', error: err.message })
      } else {
        results.collections.push('orders_active (已存在)')
      }
    }

    // 创建 orders_active 索引
    try {
      // 注意：微信云开发不支持直接创建索引，需要通过数据库控制台创建
      // 这里只记录需要创建的索引
      results.indexes.push({
        collection: 'orders_active',
        indexes: [
          { field: 'status', order: 1 },
          { field: 'passengerOpenId', order: 1 },
          { field: 'driverOpenId', order: 1 }
        ]
      })
      console.log('📝 需要为 orders_active 创建索引: status, passengerOpenId, driverOpenId')
    } catch (err) {
      results.errors.push({ index: 'orders_active', error: err.message })
    }

    // 7. 创建 orders_history 集合
    try {
      await db.createCollection('orders_history')
      results.collections.push('orders_history')
      console.log('✅ 创建集合: orders_history')
    } catch (err) {
      if (err.errCode !== -1) {
        results.errors.push({ collection: 'orders_history', error: err.message })
      } else {
        results.collections.push('orders_history (已存在)')
      }
    }

    // 8. 创建 order_bids 集合并创建索引
    try {
      await db.createCollection('order_bids')
      results.collections.push('order_bids')
      console.log('✅ 创建集合: order_bids')
    } catch (err) {
      if (err.errCode !== -1) {
        results.errors.push({ collection: 'order_bids', error: err.message })
      } else {
        results.collections.push('order_bids (已存在)')
      }
    }

    // 创建 order_bids 索引
    try {
      results.indexes.push({
        collection: 'order_bids',
        indexes: [
          { field: 'orderId', order: 1 },
          { field: 'driverOpenId', order: 1 },
          { field: 'status', order: 1 }
        ]
      })
      console.log('📝 需要为 order_bids 创建索引: orderId, driverOpenId, status')
    } catch (err) {
      results.errors.push({ index: 'order_bids', error: err.message })
    }

    // 9. 为 orders_active 集合添加 schemaVersion 字段（如果集合中有数据）
    try {
      const updateResult = await db.collection('orders_active')
        .where({})
        .update({
          data: {
            schemaVersion: 1
          }
        })
      console.log(`✅ 更新 orders_active schemaVersion: ${updateResult.stats.updated} 条记录`)
      results.schemaVersion = {
        collection: 'orders_active',
        updated: updateResult.stats.updated
      }
    } catch (err) {
      console.warn('⚠️ 更新 schemaVersion 失败（可能集合为空）:', err.message)
    }

    console.log('[initDatabase] 数据库初始化完成')

    return {
      success: true,
      code: 200,
      message: '数据库初始化完成',
      data: results
    }
  } catch (err) {
    console.error('[initDatabase] 初始化失败:', err)
    return {
      success: false,
      code: 500,
      message: '数据库初始化失败',
      error: err.message
    }
  }
}

