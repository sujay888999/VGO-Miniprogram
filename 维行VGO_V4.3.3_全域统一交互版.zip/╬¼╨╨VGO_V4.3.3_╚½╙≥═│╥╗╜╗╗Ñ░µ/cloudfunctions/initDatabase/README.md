# 数据库初始化云函数

## 功能说明

此云函数用于初始化数据库结构，包括：
- 创建核心集合
- 记录需要创建的索引（索引需要在微信开发者工具中手动创建）

## 使用方法

1. 在微信开发者工具中右键点击 `cloudfunctions/initDatabase` 文件夹
2. 选择"上传并部署：云端安装依赖"
3. 在小程序中调用：

```javascript
wx.cloud.callFunction({
  name: 'initDatabase',
  success: res => {
    console.log('初始化结果:', res.result)
  }
})
```

## 需要手动创建的索引

由于微信云开发不支持通过代码创建索引，需要在微信开发者工具的数据库控制台中手动创建以下索引：

### orders_active 集合
- `status` (升序)
- `passengerOpenId` (升序)
- `driverOpenId` (升序)

### order_bids 集合
- `orderId` (升序)
- `driverOpenId` (升序)
- `status` (升序)

## 注意事项

- 集合如果已存在，不会报错
- 索引需要在数据库控制台中手动创建
- schemaVersion 字段会更新到 orders_active 集合的所有现有记录

