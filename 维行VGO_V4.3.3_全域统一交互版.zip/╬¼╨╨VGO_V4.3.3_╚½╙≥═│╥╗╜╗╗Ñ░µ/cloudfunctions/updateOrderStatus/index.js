const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  // DEBUG 日志：打印入参
  console.log('📝 updateOrderStatus DEBUG - event:', JSON.stringify(event, null, 2));
  
  const { orderId, status, driverLocked } = event;

  if (!orderId || !status) {
    return {
      success: false,
      code: 400,
      message: "missing params"
    };
  }

  try {
    const updateData = {
      updateTime: new Date()
    };

    // 状态联动 driverLocked / selectedBidId
    // 兼容新状态和旧状态
    const normalizedStatus = status === 'going' ? 'tripStarted' : 
                            status === 'finished' ? 'completed' : 
                            status === 'canceled' ? 'cancelled' : status;
    
    if (normalizedStatus === 'accepted') {
      // 乘客确认司机后，锁定司机
      updateData.driverLocked = true;
    } else if (normalizedStatus === 'tripStarted' || normalizedStatus === 'picking' || normalizedStatus === 'onboard') {
      // 行程中，保持锁定
      // 不修改 driverLocked
    } else if (normalizedStatus === 'completed') {
      // 完成可以保留 driverLocked 状态或按需清理
      // 这里保留 driverLocked 状态，不进行清理
    } else if (normalizedStatus === 'cancelled') {
      // 订单取消，解锁司机，清空 selectedBidId
      updateData.driverLocked = false;
      updateData.selectedBidId = '';
      updateData.driverOpenId = '';
      updateData.driverPhone = '';
    }
    
    // 使用标准化后的状态
    updateData.status = normalizedStatus;

    // 如果传入了 driverLocked，则更新该字段（但 accepted 状态会覆盖）
    if (driverLocked !== undefined && status !== 'accepted') {
      updateData.driverLocked = driverLocked;
    }

    await db.collection("orders_active").doc(orderId).update({
      data: updateData
    });

    console.log('✅ updateOrderStatus - 订单状态已更新:', {
      orderId,
      status,
      driverLocked: updateData.driverLocked
    });

    return {
      success: true,
      code: 200,
      message: "order updated"
    };

  } catch (err) {
    console.error("❌ updateOrderStatus error:", err);
    return {
      success: false,
      code: 500,
      message: err.message
    };
  }
};