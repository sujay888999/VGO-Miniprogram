const cloud = require('wx-server-sdk')

// 绑定你当前环境（你给我的那个）
cloud.init({
  env: 'cloudbase-6g92d8af5bbb55dd'
})

const db = cloud.database()

exports.main = async (event) => {
  const openid = event.openid || (event.userInfo && event.userInfo.openId)
  console.log("📌 [listPassengerOrders] 查询乘客订单, openid =", openid)

  if (!openid) {
    return { data: [], errMsg: 'no-openid' }
  }

  const res = await db.collection('orders_active')
    .where({
      passengerOpenId: openid   // ✅ 和你数据库字段一致
    })
    .orderBy('createdAt', 'desc')
    .get()

  console.log("📌 [listPassengerOrders] 查询结果数量 =", res.data.length)

  return {
    data: res.data,
    errMsg: 'ok'
  }
}
