const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

exports.main = async (event) => {
  const db = cloud.database()
  const _ = db.command
  const { orderId, bidId, driverOpenId, driverPhone } = event

  // 校验参数：必须 orderId & driverOpenId & bidId
  if (!orderId || !driverOpenId || !bidId) {
    return {
      success: false,
      code: 400,
      message: '参数缺失：必须提供 orderId、driverOpenId 和 bidId'
    }
  }

  try {
    // 1) 查 orders 表确认订单存在且 status in ['waiting', 'bidding'] 且 driverLocked == false
    const orderDoc = await db.collection('orders_active').doc(orderId).get();
    if (!orderDoc.data) {
      return {
        success: false,
        code: 404,
        message: '订单不存在'
      };
    }

    const order = orderDoc.data;
    const normalizedStatus = order.status === 'waitingDriverBid' ? 'waiting' : 
                            order.status === 'bidPending' ? 'bidding' : 
                            order.status;

    if (!['waiting', 'bidding'].includes(normalizedStatus)) {
      return {
        success: false,
        code: 400,
        message: '订单状态不允许选择司机'
      };
    }

    if (order.driverLocked === true) {
      return {
        success: false,
        code: 400,
        message: '订单已被锁定'
      };
    }

    // 2) 查 bids 表获取该 bid 记录，验证 driverOpenId 匹配
    const bidDoc = await db.collection('orders_bids').doc(bidId).get();
    if (!bidDoc.data) {
      return {
        success: false,
        code: 404,
        message: '报价不存在'
      };
    }

    const bid = bidDoc.data;
    if (bid.orderId !== orderId) {
      return {
        success: false,
        code: 400,
        message: '报价与订单不匹配'
      };
    }

    if (bid.driverOpenId !== driverOpenId) {
      return {
        success: false,
        code: 400,
        message: '司机身份不匹配'
      };
    }

    // 3) 更新 orders：
    //    - selectedBidId = bidId
    //    - selectedDriverOpenId = 该 driverOpenId
    //    - driverLocked = true
    //    - status = 'accepted'
    await db.collection('orders_active').doc(orderId).update({
      data: {
        selectedBidId: bidId,
        selectedDriverOpenId: driverOpenId,
        driverOpenId: driverOpenId, // 兼容字段
        driverPhone: driverPhone || bid.driverPhone || '',
        // acceptedDriver 结构兼容 order_flow / completeTrip / confirmBoarding
        acceptedDriver: {
          driverOpenId: driverOpenId,
          phone: driverPhone || bid.driverPhone || '',
          price: bid.price,
          bidId: bidId
        },
        driverLocked: true, // 锁定订单，不再在抢单大厅显示
        status: 'accepted', // 乘客已选择司机，订单状态为已接单
        updateTime: db.serverDate()
      }
    });

    // 4) 更新 bids：
    //    - 该 bid：status = 'selected'
    //    - 同一个 orderId 其他所有 bid：status = 'failed'
    await db.collection('orders_bids').doc(bidId).update({
      data: {
        status: 'selected',
        updateTime: db.serverDate()
      }
    });

    await db.collection('orders_bids')
      .where({
        orderId: orderId,
        status: 'pending',
        _id: _.neq(bidId) // 排除当前选中的 bid
      })
      .update({
        data: {
          status: 'failed',
          updateTime: db.serverDate()
        }
      });

    console.log('✅ selectDriver - 订单已更新:', {
      orderId,
      driverOpenId,
      bidId,
      status: 'accepted',
      driverLocked: true
    });

    return {
      success: true,
      code: 200,
      message: "已选择司机"
    }
  } catch (err) {
    console.error('❌ selectDriver error:', err)
    return {
      success: false,
      code: 500,
      message: err.message || '服务器错误'
    }
  }
}
