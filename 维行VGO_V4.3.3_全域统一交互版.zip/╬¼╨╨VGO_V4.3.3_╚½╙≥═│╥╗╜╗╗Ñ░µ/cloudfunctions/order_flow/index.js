const cloud = require('wx-server-sdk');

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

const db = cloud.database();

const _ = db.command;

const ACTIVE = db.collection("orders_active");
const BIDS = db.collection("orders_bids");
const HISTORY = db.collection("orders_history");
const users = db.collection("users");

/**
 * order_flow 云函数入口
 * 所有涉及订单生命周期的操作均从这里进入
 *
 * action 类型清单（后续会逐步扩展）：
 * - publish         乘客发布订单
 * - bid             司机报价
 * - selectDriver    乘客选择司机
 * - start           司机开始接驾
 * - onboard         乘客确认上车
 * - finish          行程结束
 * - cancel          乘客/司机取消订单
 */

// 🚀 order_flow 入口分离版 — 乘客与司机各自走自己的分支
exports.main = async (event, context) => {
  console.log('🚀 order_flow triggered:', event)

  const action = event.action
  const role = event.role

  // 兼容旧版：参数可能包在 event.data 里
  let data = event.data || {}
  if (!event.data) {
    const { action, role, ...rest } = event
    data = rest
  }

  try {
    // ================= 乘客端 =================
    if (role === 'passenger' || (!role && ['createOrder','listPassengerOrders','getOrderDetail','listBids','confirmDriver'].includes(action))) {
      switch (action) {
        case 'createOrder': return createOrder(data)
        case 'listPassengerOrders': return listPassengerOrders(data)
        case 'getOrderDetail': return getOrderDetail(data)
        case 'listBids': return listBids(data)
        case 'confirmDriver': return confirmDriver(data)
        default: return { success: false, message: `乘客端未知 action: ${action}` }
      }
    }

    // ================= 司机端 =================
    if (role === 'driver' || (!role && ['listDriverOrders','submitBid','checkDriverLock','startPickup','startDrive','confirmOnboard','finishTrip','updateLocation','cancelOrder'].includes(action))) {
      switch (action) {
        case 'listDriverOrders': return listDriverOrders(data)
        case 'submitBid': return submitBid(data, context)
        case 'checkDriverLock': return checkDriverLock(data, context)
        case 'startPickup': return startPickup(data)
        case 'startDrive': return startDrive(data)
        case 'confirmOnboard': return confirmOnboard(data)
        case 'finishTrip': return finishTrip(data)
        case 'updateLocation': return updateLocation(data)
        case 'cancelOrder': return cancelOrder(data)
        default: return { success: false, message: `司机端未知 action: ${action}` }
      }
    }

    return { success: false, code: 400, message: `未指定 role 或 action` }
  } catch (err) {
    console.error('❌ order_flow error:', err)
    return { success: false, code: 500, message: err.message }
  }
}
/**********************
 * 下面的函数是占位符
 * 后续步骤逐个实现
 **********************/
async function publishOrder(data) {
  console.log("🟢 publishOrder invoked:", data);

  const {
    passengerOpenId,
    from,
    to,
    fromAddress,
    toAddress,
    distance,
    duration,
    remark
  } = data;

  // 参数校验
  if (!passengerOpenId || !from || !to) {
    return { success: false, code: 400, message: "缺少必要参数 passengerOpenId / from / to" };
  }

  try {
    // 构建订单数据结构
    const orderData = {
      passengerOpenId,
      from,               // 起点坐标 {lat, lng}
      to,                 // 终点坐标 {lat, lng}
      fromAddress,        // 起点名称（字符串）
      toAddress,          // 终点名称（字符串）
      distance: distance || 0,
      duration: duration || 0,
      remark: remark || "",
      status: "waiting",  // 初始状态：等待司机报价
      driver: null,       // 未选司机
      bids: [],           // 报价列表
      createTime: new Date(),
      driverLocked: false // 未锁定司机
    };

    // 写入 orders_active 集合
    const res = await db.collection("orders_active").add({ data: orderData });

    console.log("🚀 publishOrder success, orderId:", res._id);
    return {
      success: true,
      code: 200,
      message: "订单创建成功",
      orderId: res._id
    };

  } catch (err) {
    console.error("❌ publishOrder error:", err);
    return { success: false, code: 500, message: err.message };
  }
}

async function driverBid(data) {
  const { orderId, driverOpenId, price } = data

  if (!orderId || !driverOpenId || !price) {
    return { success: false, code: 400, message: '参数缺失' }
  }

  const orderRes = await ACTIVE.doc(orderId).get()
  if (!orderRes.data) {
    return { success: false, code: 404, message: '订单不存在' }
  }

  const order = orderRes.data
  const bids = order.bids || []

  // 判断是否已报价，防止重复报价
  const exist = bids.find(b => b.driverOpenId === driverOpenId)
  if (exist) {
    return { success: false, code: 409, message: '已提交过报价' }
  }

  const bid = {
    driverOpenId,
    price: Number(price),
    bidAt: new Date(),
    status: 'pending'
  }

  bids.push(bid)

  // 更新订单为报价状态
  await ACTIVE.doc(orderId).update({
    data: {
      bids,
      status: 'bidding',
      driverLocked: driverOpenId
    }
  })

  return {
    success: true,
    code: 200,
    message: '报价成功，等待乘客选择',
    data: bid
  }
}

async function createOrder(e) {
  const {
    passengerOpenId,
    passengerPhone,
    from,
    fromName,
    to,
    toName,
    distance,
    duration
  } = e

  if (!passengerOpenId || !from || !to || !fromName || !toName) {
    return { success: false, code: 400, message: '参数缺失' }
  }

  const now = new Date()

  const newOrder = {
    passengerOpenId,
    passengerPhone: passengerPhone || '',
    from,                 // 起点坐标
    fromName,             // 起点名称
    to,                   // 终点坐标
    toName,               // 终点名称
    distance: distance || 0,
    duration: duration || 0,
    status: 'waiting',    // 等待司机抢单
    driverLocked: false,
    bids: [],             // 保存所有报价
    createdAt: now,
    expireAt: new Date(now.getTime() + 30 * 60000) // 30分钟过期
  }

  const res = await ACTIVE.add({ data: newOrder })

  return {
    success: true,
    code: 200,
    message: '订单创建成功',
    data: { orderId: res._id }
  }
}

async function selectDriver(data) {
  const { orderId, bidId, driverOpenId } = data || {}

  if (!orderId || !driverOpenId) {
    return { success: false, code: 400, message: '缺少订单或司机信息' }
  }

  // 查询订单
  const orderRes = await ACTIVE.doc(orderId).get()
  const order = orderRes.data
  if (!order) {
    return { success: false, code: 404, message: '订单不存在' }
  }

  // 如果已经锁定司机则不允许重复选择
  if (order.driverLocked && order.driverOpenId && order.driverOpenId !== driverOpenId) {
    return { success: false, code: 409, message: '订单已锁定给其他司机' }
  }

  // 更新订单：锁定司机
  await ACTIVE.doc(orderId).update({
    data: {
      driverOpenId,
      driverLocked: true,
      selectedBidId: bidId || null,
      status: 'driverSelected',
      updateTime: new Date()
    }
  })

  // 更新报价状态：选中的标记为 selected，其它该订单的标记为 rejected（若有 bidId）
  if (bidId) {
    await BIDS.where({
      orderId,
      _id: bidId
    }).update({
      data: {
        status: 'selected',
        updateTime: new Date()
      }
    })

    await BIDS.where({
      orderId,
      _id: _.neq(bidId)
    }).update({
      data: {
        status: 'rejected',
        updateTime: new Date()
      }
    })
  }

  return {
    success: true,
    code: 200,
    message: '司机已锁定'
  }
}; }

// 司机提交报价
async function submitBid(e, context) {
  const { OPENID } = cloud.getWXContext()
  const { orderId, price } = e || {}

  console.log('[submitBid] recv params =', e, 'OPENID =', OPENID)

  // price 可能是字符串，这里统一转成数字
  const numPrice = Number(price)

  if (!orderId || !OPENID || Number.isNaN(numPrice)) {
    console.error('[submitBid] 参数缺失或非法', { orderId, price, OPENID })
    return {
      success: false,
      code: 400,
      message: '参数缺失',
      debug: { orderId, price, OPENID }
    }
  }

  const orderRes = await ACTIVE.doc(orderId).get()
  if (!orderRes.data) {
    console.error('[submitBid] 订单不存在', orderId)
    return { success: false, code: 404, message: '订单不存在' }
  }

  const order = orderRes.data
  const bids = Array.isArray(order.bids) ? order.bids : []
  const now = new Date()

  // 看看这个司机是否已经报过价，报过就覆盖
  const existIndex = bids.findIndex(b => b.driverOpenId === OPENID)
  const bidData = {
    id: `${OPENID}_${now.getTime()}`,
    driverOpenId: OPENID,
    price: numPrice,
    createdAt: now,
    status: 'pending'
  }

  if (existIndex >= 0) {
    bids[existIndex] = { ...bids[existIndex], ...bidData }
  } else {
    bids.push(bidData)
  }

  await ACTIVE.doc(orderId).update({
    data: {
      bids,
      status: 'bidding',
      updatedAt: now
    }
  })

  //===== 报价成功后执行司机锁单逻辑 START =====
  const { openId } = context.userInfo

  const nowTimestamp = Date.now()
  const lockMs = 60000 // 60秒锁单时间

  // 写入用户锁定时间
  await users.where({ openId }).update({
    data: {
      bidLockedUntil: nowTimestamp + lockMs
    }
  })
  console.log('🚖 司机报价成功，锁定60秒:', openId, new Date(nowTimestamp + lockMs).toLocaleString())
  //===== 报价成功后执行司机锁单逻辑 END =====

  console.log('[submitBid] success, bids length =', bids.length)

  return {
    success: true,
    code: 200,
    message: '报价成功',
    data: bidData
  }
}

// 别名函数：listBids（查询订单的报价列表）
async function listBids(args) {
  const { orderId } = args;
  if (!orderId) {
    return { success: false, code: 400, message: 'orderId 缺失' };
  }
  
  try {
    const orderRes = await ACTIVE.doc(orderId).get();
    if (!orderRes.data) {
      return { success: false, code: 404, message: '订单不存在' };
    }
    
    const bids = orderRes.data.bids || [];
    // 按价格升序排序
    bids.sort((a, b) => (a.price || 0) - (b.price || 0));
    
    return {
      success: true,
      code: 200,
      message: '获取报价列表成功',
      data: bids
    };
  } catch (err) {
    console.error('❌ listBids error:', err);
    return {
      success: false,
      code: 500,
      message: '查询报价失败'
    };
  }
}

// 别名函数：confirmDriver 映射到 selectDriver
async function confirmDriver(args) {
  return await selectDriver(args);
}

// acceptOrder：司机接受订单（确认接单）
async function acceptOrder(args) {
  return { success: false, code: 501, message: "acceptOrder 待实现" };
}

async function startPickup(data) {
  const { orderId, driverOpenId } = data

  if (!orderId || !driverOpenId) {
    return { success: false, code: 400, message: '参数缺失' }
  }

  const orderRes = await ACTIVE.doc(orderId).get()
  if (!orderRes.data) return { success: false, code: 404, message: '订单不存在' }

  if (orderRes.data.acceptedDriver.driverOpenId !== driverOpenId) {
    return { success: false, code: 403, message: '无权操作该订单' }
  }

  await ACTIVE.doc(orderId).update({
    data: {
      status: 'pickup',
      pickupAt: new Date()
    }
  })

  return { success: true, code: 200, message: '开始接驾' }
}

async function startDrive(data) { return { success: false, message: "start 未实现" }; }

async function confirmBoarding(data) {
  const { orderId, code } = data

  if (!orderId || !code) {
    return { success: false, code: 400, message: '参数缺失' }
  }

  const orderRes = await ACTIVE.doc(orderId).get()
  if (!orderRes.data) return { success: false, code: 404, message: '订单不存在' }

  const driverInfo = orderRes.data.acceptedDriver
  if (!driverInfo || !driverInfo.phone) return { success: false, code: 403, message: '司机信息缺失' }

  const tail = driverInfo.phone.slice(-4)
  if (tail !== code) return { success: false, code: 401, message: '尾号错误，请确认车辆' }

  await ACTIVE.doc(orderId).update({
    data: {
      status: 'driving',
      boardAt: new Date()
    }
  })

  return { success: true, code: 200, message: '乘客上车确认成功，已开始正式导航' }
}

/**
 * completeTrip
 * 订单完成：从 orders_active 迁移到 orders_history，并打上最终费用
 * 约定使用：acceptedDriver.price 作为本单最终车费
 */
async function completeTrip(e) {
  const { orderId, driverOpenId } = e || {}

  if (!orderId || !driverOpenId) {
    return { success: false, code: 400, message: '参数缺失' }
  }

  // 读取当前订单
  const orderRes = await ACTIVE.doc(orderId).get()
  if (!orderRes.data) {
    return { success: false, code: 404, message: '订单不存在' }
  }

  const order = orderRes.data

  // 安全校验：只能由接单司机完成自己的订单
  if (
    !order.acceptedDriver ||
    !order.acceptedDriver.driverOpenId ||
    order.acceptedDriver.driverOpenId !== driverOpenId
  ) {
    return { success: false, code: 403, message: '当前司机无权完成此订单' }
  }

  // 费用逻辑：
  // 优先使用 acceptedDriver.price（司机最终报价）作为总费用
  const fare = Number(order.acceptedDriver.price || order.price || 0)

  // 为了后期好扩展，先预留平台抽佣字段（暂不参与复杂计算）
  const platformRate = 0.2
  const platformFee = Math.round(fare * platformRate * 100) / 100
  const driverIncome = Math.round((fare - platformFee) * 100) / 100

  const now = new Date()

  // 写入历史订单
  const historyDoc = {
    ...order,
    status: 'completed',
    completedAt: now,
    finalFare: fare,
    platformFee,
    driverIncome
  }

  await HISTORY.add({
    data: historyDoc
  })

  // 从活动订单表中移除该单
  await ACTIVE.doc(orderId).remove()

  return {
    success: true,
    code: 200,
    message: '订单已完成并归档到历史记录',
    data: {
      orderId,
      finalFare: fare,
      platformFee,
      driverIncome
    }
  }
}


async function confirmOnboard(data) {
  // 为了兼容旧版，这里直接调用已有的 confirmBoarding 逻辑
  // data 里应包含 { orderId, code }
  return await confirmBoarding(data)
}

async function finishTrip(data) {
  // 为了兼容旧版，这里复用 completeTrip 的结算与归档逻辑
  // data 里应包含 { orderId, driverOpenId }
  return await completeTrip(data)
}
async function updateLocation(data) {
  const { orderId, location } = data

  if (!orderId || !location) return { success: false, code: 400, message: '参数缺失' }

  await ACTIVE.doc(orderId).update({
    data: { driverLocation: location }
  })

  return { success: true, code: 200, message: '位置已更新' }
}

async function cancelOrder(data) { return { success: false, message: "cancel 未实现" }; }

/**
 * listPassengerOrders
 * 乘客查看自己的订单列表（从 orders_active 集合查询）
 */
async function listPassengerOrders(e) {
  const { OPENID } = cloud.getWXContext()

  const res = await ACTIVE
    .where({ passengerOpenId: OPENID })
    .orderBy('createdAt', 'desc')
    .get()

  return {
    success: true,
    code: 200,
    message: '获取订单列表成功',
    data: res.data
  }
}

async function listNearbyOrders(e) {
  console.log('[order_flow] listNearbyOrders event =', e)

  try {
    // 现在先不做距离、时间过滤，只要还在可抢状态的单都返回
    const res = await ACTIVE
      .where({
        status: _.in(['waiting', 'bidding']) // 等待司机报价 / 正在报价中
      })
      .orderBy('createTime', 'desc')
      .limit(50)
      .get()

    console.log('[order_flow] listNearbyOrders count =', res.data.length)

    const { OPENID } = cloud.getWXContext()

    // 过滤掉当前司机已经报价过的订单（防止自己看到已报价订单）
    const filtered = (res.data || []).filter(order => {
      if (!Array.isArray(order.bids)) return true;
      return !order.bids.some(b => b.driverOpenId === OPENID);
    });

    return {
      success: true,
      code: 200,
      message: '抢单大厅订单获取成功',
      data: filtered
    }
  } catch (err) {
    console.error('[order_flow] listNearbyOrders error =', err)
    return {
      success: false,
      code: 500,
      message: '获取抢单订单失败',
      error: err
    }
  }
}

async function listDriverOrders(e) {
  const res = await db.collection('orders_active').where({
    status: 'waiting',
    driverLocked: false
  }).get()

  return {
    success: true,
    code: 200,
    message: '司机订单获取成功',
    data: res.data || []
  }
}

// listActiveOrders 作为 listDriverOrders 的别名
async function listActiveOrders(e) {
  return await listDriverOrders(e)
}

async function placeBid(e) {
  const { orderId, price } = e

  const { OPENID } = cloud.getWXContext()

  if (!orderId || !price) {
    return { success: false, code: 400, message: '参数缺失' }
  }

  const orderRes = await ACTIVE.doc(orderId).get()
  const order = orderRes.data

  if (!order) {
    return { success: false, code: 404, message: '订单不存在' }
  }

  // 拦截自己重复抢单
  if (order.bids?.some(b => b.driverOpenId === OPENID)) {
    return { success: false, code: 409, message: '你已报价，请等待乘客选择' }
  }

  // 写入报价
  await ACTIVE.doc(orderId).update({
    data: {
      bids: _.push({
        driverOpenId: OPENID,
        price,
        createdAt: new Date()
      }),
      driverLocked: true, // 锁单
      lockedBy: OPENID,
      lockedAt: new Date()
    }
  })

  return {
    success: true,
    code: 200,
    message: '报价成功，等待乘客选择',
    data: { price }
  }
}

async function getOrderDetail(e) {
  const { orderId } = e
  if (!orderId) return { success: false, code: 400, message: 'orderId 缺失' }

  const order = await ACTIVE.doc(orderId).get()
  return {
    success: true,
    code: 200,
    data: order.data
  }
}

// 新增：检查司机是否在报价锁定期中
async function checkDriverLock(e, context) {
  const { openId } = context.userInfo

  if (!openId) {
    return { ok: false, left: 0, message: '未获取到司机身份' }
  }

  // 查询司机信息
  const driverRes = await users.where({ openId }).get()
  if (!driverRes.data.length) {
    return { ok: true, left: 0, message: '无驾驶员记录，可报价' }
  }

  const driver = driverRes.data[0]
  const now = Date.now()
  const lockUntil = driver.bidLockedUntil || 0

  if (now < lockUntil) {
    const left = Math.ceil((lockUntil - now) / 1000)
    return {
      ok: false,
      left,
      message: `请等待 ${left} 秒后再次报价`
    }
  }

  return {
    ok: true,
    left: 0,
    message: '可正常报价'
  }
}

module.exports = {
  publishOrder,
  listPassengerOrders,
  listActiveOrders,   // 司机大厅必须依赖这个
  submitBid,
  confirmDriver,
  checkDriverLock,    // 锁单机制
  getOrderDetail      // 乘客端/司机端公共详情接口
}
