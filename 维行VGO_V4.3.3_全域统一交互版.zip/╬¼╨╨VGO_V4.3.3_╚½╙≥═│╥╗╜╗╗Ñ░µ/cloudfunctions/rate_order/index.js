const cloud = require('wx-server-sdk')

cloud.init()

const db = cloud.database()

const RATINGS = db.collection('ratings')

const HISTORY = db.collection('orders_history')

exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext()
  const { orderId, score, tags = [], content = '', targetOpenId } = event

  if (!orderId || !score || !targetOpenId) {
    return { success: false, code: 400, message: '参数缺失' }
  }

  // 检查订单存在
  const orderRes = await HISTORY.doc(orderId).get().catch(() => null)
  if (!orderRes || !orderRes.data) {
    return { success: false, code: 404, message: '订单不存在' }
  }

  await RATINGS.add({
    data: {
      orderId,
      score,
      tags,
      content,
      targetOpenId,
      fromOpenId: OPENID,
      createdAt: new Date()
    }
  })

  return { success: true, code: 200, message: '评价成功' }
}

