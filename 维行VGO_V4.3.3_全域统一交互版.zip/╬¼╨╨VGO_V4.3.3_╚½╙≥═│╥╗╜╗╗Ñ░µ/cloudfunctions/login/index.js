const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const users = db.collection('users')

exports.main = async (event, context) => {
  console.log("📌 Login function triggered, event =", event)

  const wxContext = cloud.getWXContext()
  const { phone, role } = event

  if (!phone || !role) {
    console.log("❌ Missing parameters")
    return { success: false, code: 400, msg: "MISSING_PARAMS" }
  }

  try {
    const openid = wxContext.OPENID
    console.log("📌 Detected openid =", openid)

    const query = await users.where({ _openid: openid }).limit(1).get()
    console.log("📌 DB Query Result:", query)

    let userRecord = null
    const now = new Date()

    if (query.data.length > 0) {
      console.log("📌 Existing user found, updating...")
      userRecord = query.data[0]
      await users.doc(userRecord._id).update({
        data: {
          phone,
          role,
          updateTime: now
        }
      })
      userRecord = { ...userRecord, phone, role }
    } else {
      console.log("📌 No user found, creating new user...")
      const addRes = await users.add({
        data: {
          _openid: openid,
          phone,
          role,
          avatar: "",
          createTime: now,
          updateTime: now
        }
      })
      userRecord = { _id: addRes._id, _openid: openid, phone, role, avatar: "" }
    }

    console.log("✅ Login success, returning data:", userRecord)

    return {
      success: true,
      code: 200,
      data: {
        openid,
        phone,
        role,
        avatar: userRecord.avatar || ""
      }
    }
  } catch (err) {
    console.error("🔥 SERVER ERROR:", err)
    return { success: false, code: 500, msg: "SERVER_ERROR", error: err }
  }
}

