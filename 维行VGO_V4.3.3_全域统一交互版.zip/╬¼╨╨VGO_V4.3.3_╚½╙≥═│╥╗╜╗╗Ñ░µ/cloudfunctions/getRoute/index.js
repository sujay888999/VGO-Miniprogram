const cloud = require('wx-server-sdk');

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

function toRad(d) {
  return d * Math.PI / 180;
}

function haversineDistance(fromStr, toStr) {
  const [lng1, lat1] = fromStr.split(',').map(Number);
  const [lng2, lat2] = toStr.split(',').map(Number);

  if ([lng1, lat1, lng2, lat2].some(v => Number.isNaN(v))) {
    throw new Error('Invalid coordinates');
  }

  const R = 6371000; // 地球半径，单位：米
  const φ1 = toRad(lat1);
  const φ2 = toRad(lat2);
  const Δφ = toRad(lat2 - lat1);
  const Δλ = toRad(lng2 - lng1);

  const a = Math.sin(Δφ / 2) ** 2 +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) ** 2;

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c; // 米

  return d;
}

exports.main = async (event) => {
  const { from, to } = event || {};
  console.log('🚀 getRoute local calc event =', event);

  if (!from || !to) {
    return {
      success: false,
      code: 400,
      message: '缺少参数: from 或 to',
      data: null,
    };
  }

  try {
    const distanceMeters = haversineDistance(from, to);
    const distanceKm = Number((distanceMeters / 1000).toFixed(1));

    // 假设平均车速 40km/h，估算时长（分钟）
    const durationMinutes = Math.max(
      1,
      Math.round((distanceKm / 40) * 60)
    );

    const result = {
      success: true,
      code: 200,
      message: 'OK',
      data: {
        distance: distanceKm, // 公里
        duration: durationMinutes, // 分钟
        raw: {
          calc: 'haversine',
          unit: 'km/min',
        },
      },
    };

    console.log('✅ getRoute local calc result =', result);
    return result;
  } catch (err) {
    console.error('❌ getRoute local calc error:', err);
    return {
      success: false,
      code: 500,
      message: '本地路线计算失败',
      data: null,
    };
  }
};
