const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

const db = cloud.database();
const _ = db.command;
const serverDate = db.serverDate;

/**
 * 清理过期订单云函数
 * 自动将30分钟前创建的等待状态订单标记为已取消
 */
exports.main = async (event, context) => {
  try {
    const now = Date.now();
    const expireTime = new Date(now - 30 * 60 * 1000); // 30分钟前

    console.log('📝 cleanupOrders - 开始清理过期订单，过期时间:', expireTime);

    // 查询并更新过期订单
    const result = await db.collection('orders_active')
      .where({
        status: _.in(['waiting', 'bidding', 'waitingDriverBid', 'pending', 'bidPending']), // 等待状态的订单
        createTime: _.lt(expireTime) // 创建时间早于30分钟前
      })
      .update({
        data: {
          status: 'cancelled', // 统一使用 cancelled 状态标记过期订单
          driverLocked: false, // 解锁
          selectedBidId: '',
          updateTime: serverDate()
        }
      });

    // 同时更新对应的 bids 状态为 expired 或 failed
    const expiredOrderIds = await db.collection('orders_active')
      .where({
        status: 'cancelled',
        createTime: _.lt(expireTime)
      })
      .field({ _id: true })
      .get();
    
    if (expiredOrderIds.data && expiredOrderIds.data.length > 0) {
      const orderIdList = expiredOrderIds.data.map(o => o._id);
      await db.collection('orders_bids')
        .where({
          orderId: _.in(orderIdList),
          status: 'pending'
        })
        .update({
          data: {
            status: 'expired',
            updateTime: serverDate()
          }
        });
    }

    const updatedCount = result.stats.updated || 0;
    console.log('✅ cleanupOrders - 清理完成，已取消订单数量:', updatedCount);

    return {
      success: true,
      code: 200,
      message: '清理完成',
      data: {
        updatedCount,
        expireTime: expireTime.toISOString()
      }
    };
  } catch (err) {
    console.error('❌ cleanupOrders error:', err);
    return {
      success: false,
      code: 500,
      message: err.message || '清理失败',
      error: err.toString()
    };
  }
};
