const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const _ = db.command
const orders = db.collection('orders_active')

/**
 * 状态映射函数：将旧状态转换为新状态（方案 A）
 */
function normalizeStatus(oldStatus) {
  switch (oldStatus) {
    case 'waiting':
    case '待匹配':
    case 'pending':
      return 'waitingDriverBid';
    case 'bidding':
    case 'waitingBid':
    case 'bidPending':
      return 'bidding';
    case 'matched':
    case 'accepted':
    case '司机已接单':
      return 'accepted';
    case 'going':
    case '进行中':
    case 'trip':
    case 'tripStarted':
      return 'tripStarted';
    case 'finished':
    case '已完成':
    case 'completed':
      return 'completed';
    case 'canceled':
    case 'cancelled':
    case '已取消':
      return 'cancelled';
    case 'picking':
      return 'picking';
    case 'onboard':
      return 'onboard';
    case 'passengerSelect':
      return 'passengerSelect';
    default:
      return oldStatus || 'waitingDriverBid';
  }
}

exports.main = async (event, context) => {
  // DEBUG 日志：打印入参
  console.log('📝 getOrders DEBUG - event:', JSON.stringify(event, null, 2));
  
  try {
    const { OPENID } = cloud.getWXContext();
    const { orderId, scene = 'driverHall', driverOpenId } = event;
    
    // 如果提供了 orderId，查询单个订单
    if (orderId) {
      const res = await orders.doc(orderId).get();
      if (res.data) {
        res.data.status = normalizeStatus(res.data.status);
      }
      const data = res.data ? [res.data] : [];
      console.log('🚀返回订单数量:', data.length);
      return {
        success: true,
        code: 200,
        data: data
      };
    }
    
    // 只显示 30 分钟内发布、且还在等待/报价中的订单
    const THIRTY_MIN = 30 * 60 * 1000
    const now = Date.now()
    const thirtyMinutesAgo = new Date(now - THIRTY_MIN)
    
    // driverHall 场景：司机抢单大厅
    if (scene === 'driverHall') {
      // 查询条件：status in ["waiting","bidding"], driverLocked = false, createTime >= 当前时间-30分钟
      // passengerOpenId != 当前司机openId（排除自己发布的订单）
      // status != "expired"（排除过期订单）
      const query = {
        status: _.and([
          _.in(['waiting', 'bidding', 'waitingDriverBid', 'pending', 'bidPending']),
          _.neq('expired')
        ]),
        driverLocked: false,
        createTime: _.gte(thirtyMinutesAgo) // createTime >= 当前时间-30分钟
        // 移除 passengerOpenId 过滤，避免订单消失
      };

      console.log('🚕 getOrders - 司机端抢单大厅查询条件:', JSON.stringify(query, null, 2));
      console.log('🚕 getOrders - 当前司机 OPENID:', OPENID);

      const result = await orders
        .where(query)
        .orderBy('createTime', 'desc')
        .get()

      console.log('🚕 getOrders - 返回订单数量:', result.data.length);

      // 补全 bids 数组：从 bids 集合查询每个订单的报价
      const formattedData = await Promise.all((result.data || []).map(async (item) => {
        // 查询该订单的所有报价
        let bidsList = [];
        try {
          const bidsRes = await db.collection('orders_bids')
            .where({ orderId: item._id })
            .orderBy('createTime', 'desc')
            .get();
          bidsList = bidsRes.data || [];
        } catch (err) {
          console.warn('查询报价失败:', err);
        }

        return {
          ...item,
          status: normalizeStatus(item.status),
          autoPrice: item.autoPrice || 0,
          distance: item.distance || item.distanceKm || 0,
          duration: item.duration || item.durationMin || 0,
          bids: bidsList, // 补全 bids 数组
          bidCount: bidsList.length // 报价数量
        };
      }));

      console.log('🚕 getOrders - 格式化后订单数量:', formattedData.length);

      return {
        success: true,
        code: 200,
        data: formattedData
      }
    }
    
    // driverMyOrders 场景：司机"我的订单"
    // 查询逻辑：该司机是 selectedDriverOpenId 的订单 或 该司机在 bids 集合中存在记录的订单
    if (scene === 'driverMyOrders' || scene === 'driverMine') {
      const { driverOpenId: eventDriverOpenId } = event;
      const driverOpenId = eventDriverOpenId || OPENID;
      
      if (!driverOpenId) {
        return {
          success: false,
          code: 400,
          message: '缺少司机 openId'
        };
      }

      console.log('🚕 getOrders - 司机我的订单，driverOpenId:', driverOpenId);

      // 第一步：从 bids 集合查询该司机的所有报价
      const bidsCollection = db.collection('orders_bids');
      const bidsRes = await bidsCollection
        .where({ driverOpenId: driverOpenId })
        .orderBy('createTime', 'desc')
        .get();

      const bidOrderIds = [...new Set((bidsRes.data || []).map(bid => bid.orderId))];
      console.log('🚕 getOrders - 司机报价的订单ID列表:', bidOrderIds);

      // 第二步：查询该司机是 selectedDriverOpenId 的订单
      const selectedOrdersRes = await orders
        .where({
          selectedDriverOpenId: driverOpenId
        })
        .orderBy('createTime', 'desc')
        .get();

      const selectedOrderIds = (selectedOrdersRes.data || []).map(o => o._id);

      // 合并所有相关订单ID
      const allOrderIds = [...new Set([...bidOrderIds, ...selectedOrderIds])];

      if (allOrderIds.length === 0) {
        return {
          success: true,
          code: 200,
          data: []
        };
      }

      // 第三步：批量查询订单详情
      const ordersRes = await orders
        .where({
          _id: _.in(allOrderIds)
        })
        .orderBy('createTime', 'desc')
        .get();

      // 第四步：合并数据，附加状态文本
      const myOrders = ordersRes.data.map(order => {
        const normalizedStatus = normalizeStatus(order.status);
        
        // 查找该订单对应的报价
        const bid = bidsRes.data.find(b => b.orderId === order._id);
        const bidStatus = bid ? bid.status : null;
        
        // 生成状态文本
        let statusText = '';
        if (bidStatus === 'pending') {
          statusText = '等待乘客选择';
        } else if (bidStatus === 'selected' && order.selectedDriverOpenId === driverOpenId) {
          statusText = '乘客已选择，请前往接驾';
        } else if (normalizedStatus === 'accepted' && order.selectedDriverOpenId === driverOpenId) {
          statusText = '乘客已选择，请前往接驾';
        } else if (normalizedStatus === 'tripStarted' || normalizedStatus === 'ontrip') {
          statusText = '行程中';
        } else if (normalizedStatus === 'completed' || normalizedStatus === 'finished') {
          statusText = '已完成';
        } else if (normalizedStatus === 'cancelled') {
          statusText = '已取消';
        } else {
          statusText = '等待乘客选择';
        }

        return {
          ...order,
          status: normalizedStatus,
          statusText: statusText,
          bidStatus: bidStatus,
          bidPrice: bid ? (bid.price || bid.bidPrice || 0) : 0,
          bidId: bid ? bid._id : null
        };
      });

      console.log('🚕 getOrders - 司机我的订单数量:', myOrders.length);
      return {
        success: true,
        code: 200,
        data: myOrders
      };
    }
    
    // passengerTrips 场景：乘客"我的行程"
    if (scene === 'passengerTrips') {
      const whereCondition = {
        passengerOpenId: OPENID,
        status: _.in([
          'waitingDriverBid',
          'bidding',
          'passengerSelect',
          'accepted',
          'picking',
          'onboard',
          'tripStarted',
          'completed',
          'cancelled',
          // 兼容旧状态
          'waiting',
          'waitingBid',
          'pending',
          'bidPending',
          'going',
          'finished',
          'canceled'
        ])
      };
      
      const res = await orders
        .where(whereCondition)
        .orderBy("createTime", "desc")
        .get();
      
      const ordersList = (res.data || []).map(o => {
        const normalizedStatus = normalizeStatus(o.status);
        // 生成状态文本（使用统一的状态格式化）
        const statusTextMap = {
          'waitingDriverBid': '等待司机抢单',
          'bidding': '司机报价中',
          'accepted': '司机已接单',
          'picking': '司机前往上车点',
          'onboard': '乘客已上车',
          'tripStarted': '行程中',
          'completed': '已完成',
          'cancelled': '已取消'
        };
        return {
          ...o,
          status: normalizedStatus,
          statusText: statusTextMap[normalizedStatus] || normalizedStatus
        };
      });
      
      console.log('🚀 getOrders - 乘客我的行程数量:', ordersList.length);
      return {
        success: true,
        code: 200,
        data: ordersList
      };
    }
    
    // 默认返回空数组
    return {
      success: true,
      code: 200,
      data: []
    };
  } catch (err) {
    console.error("❌ getOrders error:", err);
    return {
      success: false,
      code: 500,
      message: err.message
    };
  }
};