const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database();
const bids = db.collection('orders_bids');

exports.main = async (event, context) => {
  const { orderId, sortBy = 'composite' } = event;

  if (!orderId) {
    return {
      success: false,
      code: 400,
      message: "缺少订单ID"
    };
  }

  try {
    // 查询该订单的所有报价（不限制状态，包括 pending/selected/failed）
    let res = await bids
      .where({ orderId })
      .get();

    let bidsList = res.data || [];

    // 格式化返回数据，确保包含所有必要字段
    let formattedBids = bidsList.map(bid => ({
      bidId: bid._id, // 统一使用 bidId
      _id: bid._id, // 兼容字段
      orderId: bid.orderId,
      driverOpenId: bid.driverOpenId,
      driverPhone: bid.driverPhone || '未知',
      price: bid.price || bid.bidPrice || 0,
      bidPrice: bid.price || bid.bidPrice || 0, // 兼容字段
      rating: bid.rating || bid.driverScore || 4.8, // 司机评分（固定 4.8 暂时代替）
      distanceFromOrder: bid.distanceFromOrder || bid.distanceKm || bid.distance || 0, // 距离
      compositeScore: bid.compositeScore || 0, // 预留综合排序
      status: bid.status || 'pending',
      createTime: bid.createTime,
      updateTime: bid.updateTime
    }));

    
    // === VGO 综合排序模型（评分优先 + 距离 + 价格） ===
    if (formattedBids.length) {
      const scores = formattedBids.map(b => Number(b.rating || 4.8));
      const prices = formattedBids.map(b => Number(b.price || 0));
      const dists  = formattedBids.map(b => Number(b.distanceFromOrder || 0));

      const minScore = Math.min(...scores);
      const maxScore = Math.max(...scores);
      const minPrice = Math.min(...prices);
      const maxPrice = Math.max(...prices);
      const minDist  = Math.min(...dists);
      const maxDist  = Math.max(...dists);

      function normalize(val, min, max) {
        if (!isFinite(val)) return 0.5;
        if (max <= min) return 0.5;
        if (val <= min) return 0;
        if (val >= max) return 1;
        return (val - min) / (max - min);
      }

      formattedBids = formattedBids.map((b, idx) => {
        const s = scores[idx];
        const p = prices[idx];
        const d = dists[idx];

        const scoreScore    = normalize(s, minScore, maxScore);          // 高分更好
        const distanceScore = 1 - normalize(d, minDist, maxDist);        // 距离越近越好
        const priceScore    = 1 - normalize(p, minPrice, maxPrice);      // 价格越低越好

        const finalScore = scoreScore * 0.55 + distanceScore * 0.35 + priceScore * 0.10;

        let primaryTag = '';
        if (s >= 4.8) {
          primaryTag = '高评分';
        } else if (d <= 2) {
          primaryTag = '距离近';
        } else if (p <= (minPrice + (maxPrice - minPrice) * 0.3)) {
          primaryTag = '价格优';
        }

        return {
          ...b,
          finalScore,
          primaryTag,
          serviceScore: s,
          distanceKm: d,
          bidPrice: p
        };
      });
    }


    // 根据 sortBy 参数排序
    if (sortBy === 'price') {
      // 按价格升序
      formattedBids.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'rating') {
      // 按评分降序
      formattedBids.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'distance') {
      // 按距离升序
      formattedBids.sort((a, b) => a.distanceFromOrder - b.distanceFromOrder);
    } else {
      // 默认综合排序：按 createTime 升序（最早报价优先）
      formattedBids.sort((a, b) => {
        const timeA = new Date(a.createTime).getTime();
        const timeB = new Date(b.createTime).getTime();
        return timeA - timeB;
      });
    }

    console.log('📝 getBids - 订单ID:', orderId, '报价数量:', formattedBids.length, '排序方式:', sortBy);

    return {
      success: true,
      code: 200,
      data: formattedBids
    };
  } catch (e) {
    console.error('❌ getBids error:', e);
    return {
      success: false,
      code: 500,
      message: '查询失败',
      error: e.message || e.toString()
    };
  }
};
