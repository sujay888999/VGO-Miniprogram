exports.main = async (event, context) => {
  const cloud = require("wx-server-sdk");
  cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

  const db = cloud.database();
  const _ = db.command;
  const orders = db.collection("orders_active");

  const { orderId, price } = event;

  if (!orderId || !price) {
    return { success: false, msg: "缺少参数" };
  }

  // 在插入 bid 后添加：更新订单状态为 bidding
  await orders.doc(orderId).update({
    data: {
      status: 'bidding',
      updateTime: new Date()
    }
  });

  // 确保返回结构中包含 success = true
  return {
    success: true,
    msg: "报价成功"
  };
};

