const cloud = require('wx-server-sdk')

cloud.init()

const db = cloud.database()

const RATINGS = db.collection('ratings')

exports.main = async (event, context) => {
  const { userOpenId } = event

  if (!userOpenId) return { success: false, message: 'userOpenId 缺失' }

  const list = (await RATINGS.where({ targetOpenId: userOpenId }).get()).data

  if (!list.length) {
    return { success: true, score: 5.0, count: 0 } // 默认5星
  }

  const score = (list.reduce((x, y) => x + y.score, 0) / list.length).toFixed(1)
  return { success: true, score: Number(score), count: list.length }
}

