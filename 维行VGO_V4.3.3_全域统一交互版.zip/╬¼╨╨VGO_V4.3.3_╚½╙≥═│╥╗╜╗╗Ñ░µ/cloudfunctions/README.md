# 云函数目录

在后续阶段将实现以下云函数：

- login
- publishTrip
- acceptBid
- bidTrip
- createBid

注意：路线规划功能已迁移到客户端，使用腾讯地图 SDK 直接调用。

目前预留目录结构，方便后续开发与部署。

