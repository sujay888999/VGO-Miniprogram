const cloud = require('wx-server-sdk');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

const db = cloud.database();
const bidsCollection = db.collection('orders_bids');
const ordersCollection = db.collection('orders_active');

exports.main = async (event) => {
  console.log('🚕 createBid event =', event);

  const {
    orderId,
    driverOpenId,
    driverPhone,
    price, // 手动报价金额
    unitPrice, // 每公里单价
    distanceKm, // 订单预估里程
    durationMin, // 订单预估时间
  } = event || {};

  // 1) 校验参数：orderId, driverOpenId, price 或 (unitPrice + distanceKm)
  if (!orderId || !driverOpenId) {
    return {
      success: false,
      code: 400,
      message: "参数缺失",
      data: null,
    };
  }

  // 如果没有传入 price，必须有 unitPrice 和 distanceKm
  if (!price && (!unitPrice || !distanceKm)) {
    return {
      success: false,
      code: 400,
      message: "参数缺失：需要 price 或 (unitPrice + distanceKm)",
      data: null,
    };
  }

  try {
    // 2) 根据 orderId 从 orders 集合读取订单
    const orderDoc = await ordersCollection.doc(orderId).get();
    if (!orderDoc.data) {
      return {
        success: false,
        code: 404,
        message: '订单不存在',
        data: null,
      };
    }

    const order = orderDoc.data;

    // 确保订单状态在允许报价的范围内（兼容旧状态）
    const allowedStatuses = ['waitingDriverBid', 'bidding', 'waiting', 'waitingBid', 'pending', 'bidPending'];
    if (!allowedStatuses.includes(order.status)) {
      return {
        success: false,
        code: 400,
        message: '订单状态不允许报价',
        data: null,
      };
    }

    // 确保未被锁定且未被选中其他司机
    if (order.driverLocked === true || order.selectedDriverOpenId) {
      return {
        success: false,
        code: 400,
        message: '订单已被其他司机接单',
        data: null,
      };
    }

    // 3) 计算报价价格逻辑
    let finalPrice = Number(price);
    if (!Number.isFinite(finalPrice) || finalPrice <= 0) {
      // 使用 unitPrice * distanceKm 生成，保留 1~2 位小数
      const orderDistanceKm = distanceKm || order.distanceKm || order.routeInfo?.distance || 3;
      const orderUnitPrice = Number(unitPrice) || 2;
      finalPrice = parseFloat((orderDistanceKm * orderUnitPrice).toFixed(2));
      console.log('✅ createBid 自动计算报价:', { orderDistanceKm, orderUnitPrice, finalPrice });
    }

    // 验证报价金额必须大于 0
    if (!Number.isFinite(finalPrice) || finalPrice <= 0) {
      return {
        success: false,
        code: 400,
        message: '报价金额必须大于0',
        data: null,
      };
    }

    const now = new Date();
    const orderDistanceKm = distanceKm || order.distanceKm || order.routeInfo?.distance || 0;
    const orderDurationMin = durationMin || order.durationMin || order.routeInfo?.duration || 0;
    const orderUnitPrice = Number(unitPrice) || 2;

    // 4) 在 bids 集合中插入一条记录
    const addRes = await bidsCollection.add({
      data: {
        orderId,
        driverOpenId,
        driverPhone: driverPhone || '',
        price: finalPrice,
        unitPrice: orderUnitPrice,
        distanceKm: orderDistanceKm,
        durationMin: orderDurationMin,
        driverScore: 4.8, // 暂时固定值，后续可从 driverProfile 中取
        driverFinishedCount: 0, // 暂时固定值，后续可从 driverProfile 中取
        status: 'pending', // 初始状态：待乘客选择
        createTime: now,
        updateTime: now,
        // TODO: 预留扩展字段
        rating: 4.8, // 司机评分（兼容字段）
        distanceFromOrder: orderDistanceKm, // 距订单起点距离
        compositeScore: 0 // 综合排序分数（预留）
      },
    });

    const bidId = addRes._id;
    console.log('✅ createBid inserted bid:', bidId);

    // 5) 更新 orders 集合
    // 当任意司机报价成功，在订单表 orders 中自动写入 bidding 状态
    const updateData = {
      status: 'bidding', // 无论当前状态如何，报价后都更新为 bidding
      updateTime: new Date(),
    };
    
    // 确保 driverLocked 保持 false，让订单继续在抢单大厅显示

    // 将报价添加到 bids 数组（如果使用数组方式）
    const currentBids = order.bids || [];
    currentBids.push({
      _id: bidId,
      driverOpenId,
      driverPhone: driverPhone || '',
      price: finalPrice,
      createTime: now
    });
    updateData.bids = currentBids;

    await ordersCollection.doc(orderId).update({
      data: updateData,
    });

    console.log('✅ createBid - 订单状态更新:', {
      orderId,
      oldStatus: order.status,
      newStatus: updateData.status,
      bidId,
      price: finalPrice
    });

    return {
      success: true,
      code: 200,
      message: "报价成功",
      data: { bidId: bidId, price: finalPrice },
    };
  } catch (err) {
    console.error('❌ createBid error:', err);
    return {
      success: false,
      code: 500,
      message: '服务器错误',
      data: null,
    };
  }
};
