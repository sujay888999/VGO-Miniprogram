const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const _ = db.command
const ordersCollection = db.collection('orders_active')

exports.main = async (event, context) => {
  try {
    const { OPENID } = cloud.getWXContext();

    // 参数映射
    const { 
      passengerOpenId,
      passengerPhone,
      fromAddress, 
      toAddress, 
      fromLocation, 
      toLocation, 
      dateTime,
      remark = "",
      distance = 0,
      duration = 0
    } = event;

    if (!passengerOpenId || !fromAddress || !toAddress || !fromLocation || !toLocation || !dateTime) {
      return { 
        success: false, 
        code: 400, 
        message: "缺少参数：起点、终点、时间或用户身份"
      };
    }

    // 格式化地址：确保 fromAddress / toAddress 是字符串
    const formatAddressString = (address) => {
      if (typeof address === 'string') return address;
      if (typeof address === 'object' && address !== null) {
        return address.name || address.address || '';
      }
      return '';
    };

    // 统一入库字段格式
    const distanceKm = parseFloat(event.distanceKm || distance || 3);
    const durationMin = parseInt(event.durationMin || duration || 0);

    const data = {
      passengerOpenId: passengerOpenId || OPENID,
      passengerPhone: passengerPhone || '',
      fromAddress: formatAddressString(fromAddress), // 字符串
      toAddress: formatAddressString(toAddress), // 字符串
      fromLocation: fromLocation || {}, // 对象，包含 lat, lng
      toLocation: toLocation || {}, // 对象，包含 lat, lng
      startLocation: fromLocation,
      endLocation: toLocation,
      dateTime: dateTime || new Date(),
      remark: remark || '',
      distance: distanceKm,
      duration: durationMin,
      routeInfo: {
        distance: distanceKm, // 公里
        duration: durationMin // 分钟
      },
      status: "waitingDriverBid", // 初始状态：等待司机抢单/报价
      distanceKm: distanceKm,
      durationMin: durationMin,
      driverOpenId: "", // 已选中的司机 openid（未选司机则为空）
      driverPhone: "", // 司机手机号
      driverLocked: false, // 是否锁定给某个司机
      bids: [], // 存放所有报价记录
      selectedBidId: "", // 乘客最终选中的报价 id
      createTime: new Date(),
      updateTime: new Date()
    };

    const result = await ordersCollection.add({ data });

    console.log('✅ createOrder 新订单插入成功 - _id:', result._id);

    return {
      success: true,
      code: 200,
      message: "订单创建成功",
      data: { 
        orderId: result._id,
        status: data.status
      }
    };
  } catch (err) {
    console.error('🔥 createOrder ERROR:', err);
    return {
      success: false,
      code: 500,
      message: '服务器错误',
      error: err.toString(),
    };
  }
}

