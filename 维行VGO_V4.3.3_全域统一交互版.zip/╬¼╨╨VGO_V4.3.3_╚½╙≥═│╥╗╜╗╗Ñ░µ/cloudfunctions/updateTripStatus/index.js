const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()

exports.main = async (event, context) => {
  const { orderId, status } = event

  if (!orderId || !status) {
    return { success: false, code: 400, message: "缺少 orderId 或 status 参数" }
  }

  try {
    const updateData = {
      status,
      updateTime: new Date()
    };

    // 如果状态为 cancelled，重置 driverLocked 和 selectedBidId
    if (status === 'cancelled') {
      updateData.driverLocked = false;
      updateData.selectedBidId = '';
    }

    await db.collection('orders_active').doc(orderId).update({
      data: updateData
    })

    return { success: true, code: 200, message: "状态更新成功" }
  } catch (err) {
    return { success: false, code: 500, message: err.message }
  }
}

