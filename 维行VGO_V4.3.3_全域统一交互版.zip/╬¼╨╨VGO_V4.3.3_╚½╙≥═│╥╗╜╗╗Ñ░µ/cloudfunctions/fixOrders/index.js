const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const _ = db.command

/**
 * 自动清理数据库旧订单缺失字段
 * 修复缺失 autoPrice 字段的订单
 */
exports.main = async (event, context) => {
  try {
    console.log('📝 fixOrders - 开始修复缺失 autoPrice 字段的订单...');

    const result = await db.collection('orders_active')
      .where({
        autoPrice: _.exists(false)
      })
      .update({
        data: {
          autoPrice: 0,
          updateTime: new Date()
        }
      });

    const updatedCount = result.stats.updated || 0;
    console.log(`✅ fixOrders - 修复完成，更新了 ${updatedCount} 条订单`);

    return {
      success: true,
      code: 200,
      message: '修复完成',
      data: {
        updatedCount,
        timestamp: new Date().toISOString()
      }
    };
  } catch (err) {
    console.error('❌ fixOrders error:', err);
    return {
      success: false,
      code: 500,
      message: err.message || '修复失败',
      error: err.toString()
    };
  }
};

