const cloud = require('wx-server-sdk')

cloud.init()

const db = cloud.database()

const HISTORY = db.collection('orders_history')

exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext()

  const startOfToday = new Date()
  startOfToday.setHours(0, 0, 0, 0)

  const startOfTomorrow = new Date(startOfToday)
  startOfTomorrow.setDate(startOfToday.getDate() + 1)

  // 今日收入
  const todayRes = await HISTORY.where({
    driverOpenId: OPENID,
    completedAt: db.command.gte(startOfToday).and(db.command.lt(startOfTomorrow))
  }).get()

  // 使用 driverIncome（司机实际收入），兼容 fare 和 finalFare 字段
  const todayTotal = todayRes.data.reduce((sum, o) => sum + (o.driverIncome || o.finalFare || o.fare || 0), 0)

  // 累计收入
  const allRes = await HISTORY.where({ driverOpenId: OPENID }).get()
  const allTotal = allRes.data.reduce((sum, o) => sum + (o.driverIncome || o.finalFare || o.fare || 0), 0)

  return {
    success: true,
    code: 200,
    message: '收入获取成功',
    data: {
      todayOrderCount: todayRes.data.length,
      todayTotal,
      allTotal
    }
  }
}

