const cloud = require('wx-server-sdk')

cloud.init()

const db = cloud.database()
const _ = db.command
const ordersCollection = db.collection('orders_active')

exports.main = async (event, context) => {
  return {
    code: 0,
    msg: "FUNCTION_READY",
    event
  }
}
const cloud = require('wx-server-sdk')

cloud.init()

const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  return {
    code: 0,
    msg: "FUNCTION_READY",
    event
  }
}

