const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()

const orders = db.collection('orders_active')
const bids = db.collection('orders_bids')

exports.main = async(event, context)=>{
  const { bidId, orderId } = event
  
  if(!orderId){
    return { success:false, code:400, message:"参数缺失：订单ID不能为空" }
  }

  try {
    // 如果提供了 bidId，更新报价状态
    if (bidId) {
      await bids.doc(bidId).update({
        data: { status: "accepted" }
      })
    }

    // 更新订单状态为"行程进行中"，并记录开始时间
    const now = new Date();
    await orders.doc(orderId).update({
      data: { 
        status: 'tripStarted',
        going: true,
        startTime: now,
        updateTime: now
      }
    })

    console.log('✅ acceptBid 成功，订单状态更新为"进行中"');

    return { success:true, code:200, message:"接单成功" }
  } catch(err){
    console.error('🔥 acceptBid ERROR:', err);
    return { 
      success: false, 
      code: 500, 
      message: "服务器错误", 
      error: err.message 
    }
  }
}
